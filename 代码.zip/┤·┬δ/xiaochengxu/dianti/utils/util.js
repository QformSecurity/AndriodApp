function formatTime(date) {
    var year = date.getFullYear()
    var month = date.getMonth() + 1
    var day = date.getDate()

    var hour = date.getHours()
    var minute = date.getMinutes()
    var second = date.getSeconds()


    return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatNumber(n) {
    n = n.toString()
    return n[1] ? n : '0' + n
}
function toDate(number,flag,part) {
    number=number/1000;
    var n = number;
    var date = new Date(parseInt(n) * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    if(flag){
        if(part == "year"){
            return y;
        }else if(part == "month"){
            return m;
        }else if(part == "date"){
            return n;
        }
        return y + '-' + m + '-' + d;
    }
    //return y + '-' + m + '-' + d + ' ' + h + ':' + minute+':' + second;
    return  m + '-' + d + ' ' + h + ':' + minute;
    //return y + '-' + m + '-' + d;
};
function toDate2(number,flag,part) {
    number=number/1000;
    var n = number;
    var date = new Date(parseInt(n) * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    if(flag){
        if(part == "year"){
            return y;
        }else if(part == "month"){
            return m;
        }else if(part == "date"){
            return n;
        }
        return y + '-' + m + '-' + d;
    }
    //return y + '-' + m + '-' + d + ' ' + h + ':' + minute+':' + second;
    return  h + ':' + minute;
    //return y + '-' + m + '-' + d;
};
function toDate3(number,flag,part) {
    number=number/1000;
    var n = number;
    var date = new Date(parseInt(n) * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    // if(flag){
    //     if(part == "year"){
    //         return y;
    //     }else if(part == "month"){
    //         return m;
    //     }else if(part == "date"){
    //         return n;
    //     }
    //     return y + '-' + m + '-' + d;
    // }
    return y + '-' + m + '-' + d + ' ' + h + ':' + minute+':' + second;
    // return  m + '-' + d + ' ' + h + ':' + minute;
    //return y + '-' + m + '-' + d;
};
function  shibie(number,result){
    let results = result
    let result_num = results.words_result_num;
    let total_high = 0
    let zuobiao = {
        row: 0,
        line: 0,
    }
    let scan_row = 0
    let scan_line = 0
    let average_high = 0
    let average_high_err = 0
    let words_result = results.words_result
    if (result_num > 0){
        for(let i=0;i<words_result.length;i++){
            total_high = total_high + words_result[i].location.height;
        }
        average_high = total_high / result_num;
        average_high_err = average_high * 0.2;
        let Key_Num_Value = []
        let Row = []
        let Line = []
        Key_Num_Value[0] = words_result[0].words;
        Row[0] = 0;
        Line[0] = 0;
        let last_key_top = words_result[0].location.top;
        for(let i=1;i<words_result.length;i++) {
            let current_top = words_result[i].location.top;
            if (last_key_top - average_high_err <= current_top && current_top <= last_key_top + average_high_err) {
                Line[i] = Line[i - 1]
                Row[i] = Row[i - 1] + 1
            } else {
                Line[i] = Line[i - 1] + 1
                Row[i] = 0
            }
            Key_Num_Value[i] = words_result[i].words
            last_key_top = current_top
        }
        for(let i=0;i<Key_Num_Value.length;i++) {
            if(number == Key_Num_Value[i]){
                scan_row = Row[i] + 1
                scan_line = Line[i] + 1
            }
        }
    }
    zuobiao.row = scan_row
    zuobiao.line = scan_line
    return zuobiao
}
function   shibie2(result){
    let results = result
    let result_num = results.words_result_num;
    let zuobiao = {
        info: '',
        number: '',
    }
    let max_size = 0
    let max_word_id = ""
    let words_result = results.words_result
    if (result_num > 0){
        for(let i=0;i<words_result.length;i++){
            let size = words_result[i].location.height * words_result[i].location.width
            if(size>max_size){
                max_size = size
                max_word_id = i
            }
        }
        zuobiao.info = words_result[max_word_id].words
    }
    return zuobiao
}
module.exports = {
    formatTime: formatTime,
    toDate:toDate,
    toDate2:toDate2,
    toDate3:toDate3,
    shibie: shibie,
    shibie2: shibie2,
    request: function(method,type,data,success,fail){
        const that = this;
        const app = getApp();
        data.timestamp = parseInt((new Date()).getTime());
        //data.openid = app.globalData.openid;
       // data.token = app.globalData.token;
        ////console.log(type);
        if(type=='GET'){
            wx.request({
                // 必需
                url: app.globalData.url+method,
                data: data,
                method:"GET",
                header: {
                    'Content-Type':'application/json;charset=utf-8',
                },
                success: function (res) {
                    if(res.data.code!=200){
                        wx.showToast({
                            title:res.data.msg,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                    else{
                        success(res.data)
                    }
                },
                fail:fail,
            })
        }
        else{
            wx.request({
                // 必需
                url: app.globalData.url+method,
                data: data,
                method:"POST",
                header: {
                    'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
                    // 'Content-Type':'application/json;charset=utf-8',
                },
                success: function (res) {
                    if(res.data.code!=200){
                        wx.showToast({
                            title:res.data.msg,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                    else{
                        success(res.data)
                    }
                },
                fail,
            })
        }
    },
    request2: function(method,type,data,success,fail){
        const that = this;
        const app = getApp();
        data.timestamp = parseInt((new Date()).getTime());
        //data.openid = app.globalData.openid;
        // data.token = app.globalData.token;
        ////console.log(type);
        wx.request({
            // 必需
            url: app.globalData.url+method,
            data: data,
            method:type,
            header: {
                'Content-Type':'application/json;charset=utf-8',
            },
            success: function (res) {
                if(res.data.code!=200){
                    wx.showToast({
                        title:res.data.msg,
                        icon: 'none',
                        duration: 2000
                    })
                }
                else{
                    success(res.data)
                }
            },
            fail:fail,
        })
    },
}
