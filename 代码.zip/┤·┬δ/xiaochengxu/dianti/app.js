//app.js

App({
  onLaunch: function () {
    const that = this;
      // 展示本地存储能力
      that.globalData.userInfo = wx.getStorageSync('userInfo') || null;
    // console.log(lang)
    // if (wx.getStorageSync("local") == "") {
    //   let localList = require("./utils/locales.js")
    //   if (lang == "zh" || lang == "zh_CN") {
    //     wx.setStorageSync("local", localList.localList.zh)
    //   } else {
    //     wx.setStorageSync("local", localList.localList.en)
    //   }
    // }
      // var userInfo=wx.getStorageSync('userInfo') || null;
      // ////console.log(userInfo);
      // if(userInfo!=null){
      //     that.globalData.userInfo = userInfo;
      //     ////console.log( that.globalData.userInfo);
      // }
      // else{
      //   ////console.log(userInfo)
      // }
      // wx.getSetting({
      //     success: res => {
      //         if (res.authSetting['scope.userInfo']) {
      //             // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
      //             wx.getUserInfo({
      //                 success: res => {
      //                     // 可以将 res 发送给后台解码出 unionId
      //                     console.log(res)
      //                     that.globalData.userInfo = res.userInfo;
      //                     ////console.log(res)
      //                     // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      //                     // 所以此处加入 callback 以防止这种情况
      //                 }
      //             })
      //         }
      //     }
      // })
    /*
    // 获取系统信息
    const systemInfo = wx.getSystemInfoSync();
    // 胶囊按钮位置信息
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    // 导航栏高度 = 状态栏到胶囊的间距（胶囊距上距离-状态栏高度） * 2 + 胶囊高度 + 状态栏高度
    _this.globalData.navBarHeight = (menuButtonInfo.top - systemInfo.statusBarHeight) * 2 + menuButtonInfo.height + systemInfo.statusBarHeight;
    _this.globalData.menuRight = systemInfo.screenWidth - menuButtonInfo.right;
    _this.globalData.menuBotton = menuButtonInfo.top - systemInfo.statusBarHeight;
    _this.globalData.menuHeight = menuButtonInfo.height;
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || [];
    logs.unshift(Date.now());
    wx.setStorageSync('logs', logs);
    //token
    _this.globalData.token = wx.getStorageSync('token')
    ;
    // 登录
    wx.login({
      success: function(res) {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        ////console.log(res)
      }
    })
    */
    // 获取用户信息
    // wx.getSetting({
    //   success: res => {
    //     if (res.authSetting['scope.userInfo']) {
    //       // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
    //       wx.getUserInfo({
    //         success: res => {
    //           // 可以将 res 发送给后台解码出 unionId
    //             that.globalData.userInfo = res.userInfo;
    //           console.log(res)
    //           // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //           // 所以此处加入 callback 以防止这种情况
    //         }
    //       })
    //     }
    //   }
    // })
  },

  globalData: {
    userInfo: null,
    access_token: '',
   // token:'',
   //  urlImage: 'http://192.168.1.83:8080/quanjiS1/excelDown/',
    imageUrl2: '../image/',
    urlImage: 'https://quanji.liwangzhipin.com:8080/quanjiS1/excelDown/',
    imageUrl: 'https://quanji.liwangzhipin.com:8080/quanjiS1/xiaochengxuziyuan/image/',//正式版
    imgUr: 'https://quanji.liwangzhipin.com:8080/quanjiS1/uploadImage/',//正式版
    // imgUr: 'http://192.168.31.94:8080/quanjiS1/uploadImage/',
    // imgUr: 'http://192.168.3.10:8080/quanjiS1/uploadImage/',
    // imageUrl: "http://121.89.222.43/xiaochengxu/quanji/image/",
   //   imageUrl: "http://192.168.50.243/xiaochengxu/dianshangBV/",
   //  url:'http://192.168.50.245:8080/quanjiS1/'
   //  url:'http://192.168.31.94:8080/quanjiS1/'
   //  url: "https://tmj.xinagri.com/GroupBuyApi/"
   //  url:'http://192.168.31.94:8080/quanjiS1/'
   //  url:'http://localhost:8080/quanjiS1/',
   //  url:'http://quanji.liwangzhipin.com:8081/quanjiS1/'
    urls: 'https://aip.baidubce.com/',
    url:'http://39.103.200.37/'//正式版
    // url:'https://tmj.xinagri.com/dianti/dianti/'//正式版
    // url:'https://guijie.maiquanshike.com:8090/app/'//正式版
    // url:'https://budainiu1bv.maiquanshike.com:9090/app/'//测试版 http://192.168.50.245:8080/quanjiS1/excel/save.php
  },
  dataSource: {
    number: '',
    numbers: {
      info: ""
    },
    numberList: [],
    numberList2: [],
    zuobiao: {
      row: 0,
      line: 0,
    },
  }
})
