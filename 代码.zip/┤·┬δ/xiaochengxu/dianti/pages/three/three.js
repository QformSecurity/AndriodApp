const app = getApp();
const util = require('../../utils/util.js');
let innerAudioContext = wx.createInnerAudioContext();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    number: '',
    timer: 0,
      appUrl:  app.globalData.url,
      appurls: app.globalData.urls,
      url: '',
      url1: "",
      url2: "",
      url3: "",
      url4: "",
      url5: "",
  },
  onLoad:function(){
      this.setData({
          number: app.dataSource.number
      })
      this.setData({
          number: app.dataSource.number,
          url1: app.globalData.url + "assets/page03/请拍摄电梯区域按钮.mp3",
          url2: app.globalData.url + "assets/page03/开始拍摄.mp3",
          url3: app.globalData.url + "assets/page02/是.mp3",
          url4: app.globalData.url + "assets/page02/否.mp3",
          url5: app.globalData.url + "assets/page02/上一步.mp3",
      })
      innerAudioContext.src = this.data.url1
      innerAudioContext.play();
 },
  onShow: function () {
    },
  onReady(){
    // console.log(11)
  },
  onHide(){
    // console.log(11)

  },
  queren(){
    var that = this
    let timer = that.data.timer
    timer++;
    that.setData({
      timer: timer
    })
    if (timer=== 2) {
      timer = 0;
      that.setData({
        timer: timer
      })
      console.log("双击"); //双击要执行的事件处理
      // 音频
      // if (state.number === "") {
      //   // Toast.warn("请输入要去的楼层");
      //   audiodata.url = audiodata.url1;
      //   audiodata.muted = true;
      //   audiodata.autoplay = true;
      //   return false;
      // }
      // 处理
        wx.chooseImage({
            count:'1',   // 最多可以选择的图片张数
            sizeType: ['original', 'compressed'], // ['原图','压缩图']
            sourceType: ['album', 'camera'],  // ['从相册选图','使用相机']
            success: res => {
                wx.getFileSystemManager().readFile({
                    filePath: res.tempFilePaths[0], //选择图片返回的相对路径
                    encoding: 'base64', //编码格式
                    success: res => { //成功的回调

                        // console.log('data:image/png;base64,' + res.data)
                        let data = res.data;
                        wx.request({
                            // 必需
                            url: app.globalData.urls+'rest/2.0/ocr/v1/accurate?access_token=' + app.globalData.access_token,
                            data: {
                                image: data
                            },
                            method:"POST",
                            header: {
                                'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
                            },
                            success: function (res) {
                                // // console.log(res)
                                // app.globalData.access_token = res.data.access_token
                                // // console.log(app.globalData.access_token)
                                let data = res.data
                                if(data){
                                    let zuobiao = util.shibie(app.dataSource.number,data)
                                    app.dataSource.zuobiao = zuobiao
                                    wx.navigateTo({
                                        url: '../four/four'
                                    })
                                }
                            },
                        })
                    }
                })
            }
        })
        //   wx.navigateTo({
        //     url: '../four/four'
        // })
    }
    setTimeout(function () {
      timer = that.data.timer
      if (timer === 1) {
        timer = 0;
        that.setData({
          timer: timer
        })
        console.log("单击"); //双击要执行的事件处理
          innerAudioContext.src = that.data.url2
          innerAudioContext.play();
      }
    }, 250);
    // wx.navigateTo({
    //   url: '../login/login'
    // })
  },
  quxiaoBack(){
        var that = this
        let timer = that.data.timer
        timer++;
        that.setData({
            timer: timer
        })
        if (timer=== 2) {
            timer = 0;
            that.setData({
                timer: timer
            })
            console.log("双击"); //双击要执行的事件处理
            // 音频
            // if (state.number === "") {
            //   // Toast.warn("请输入要去的楼层");
            //   audiodata.url = audiodata.url1;
            //   audiodata.muted = true;
            //   audiodata.autoplay = true;
            //   return false;
            // }
            // 处理
            wx.navigateBack({
                delta: -1
            });
        }
        setTimeout(function () {
            timer = that.data.timer
            if (timer === 1) {
                timer = 0;
                that.setData({
                    timer: timer
                })
                console.log("单击"); //双击要执行的事件处理
                innerAudioContext.src = that.data.url5
                innerAudioContext.play();
            }
        }, 250);
        // wx.navigateTo({
        //   url: '../login/login'
        // })
    },
})
