const app = getApp();
const util = require('../../utils/util.js');
let innerAudioContext = wx.createInnerAudioContext();
Page({
  /**
   * 页面的初始数据
   */
  data: {
      weizhi: false,
      numbers: {
          info: ""
      },
      number: '',
    timer: 0,
      appUrl:  app.globalData.url,
      url20: "",
      url21: "",
      url: '',
      url1: "",
      url2: "",
      url3: "",
      url4: "",
      url5: "",
  },
  onLoad:function(){
      this.setData({
          number: app.dataSource.number,
          numbers: app.dataSource.numbers,
          url1: app.globalData.url + "assets/page06/您当前在.mp3",
          url2: app.globalData.url + "assets/shuzi/未知.mp3",
          url21: app.globalData.url + "assets/page06/您可以.mp3",
          url3: app.globalData.url + "assets/page06/再次拍摄.mp3",
          url4: app.globalData.url + "assets/page06/结束.mp3",
          url5: app.globalData.url + "assets/page06/上一步.mp3",
      })
      let weizhi = true
      let url2 = this.data.url2
      for (let i = 0; i <app.dataSource.numberList.length; i++) {
          if (app.dataSource.numbers &&app.dataSource.numbers.info) {
              if (app.dataSource.numbers.info == app.dataSource.numberList[i].num) {
                  url2= app.globalData.url + app.dataSource.numberList[i].url;
                  weizhi = false;
              }
          }
      }
      innerAudioContext.src = this.data.url1
      innerAudioContext.play();
      this.setData({
          weizhi: weizhi,
          url2: url2
      })
      let that = this
      setTimeout(function (){
          innerAudioContext.src = that.data.url2
          innerAudioContext.play();
      }, 2000)
 },
  onShow: function () {
    },
  onReady(){
    // console.log(11)
  },
  onHide(){
    // console.log(11)

  },
  queren(){
    var that = this
    let timer = that.data.timer
    timer++;
    that.setData({
      timer: timer
    })
    if (timer=== 2) {
      timer = 0;
      that.setData({
        timer: timer
      })
      console.log("双击"); //双击要执行的事件处理
      // 音频
      // if (state.number === "") {
      //   // Toast.warn("请输入要去的楼层");
      //   audiodata.url = audiodata.url1;
      //   audiodata.muted = true;
      //   audiodata.autoplay = true;
      //   return false;
      // }
        wx.navigateBack({
            delta: -1
        });
    }
    setTimeout(function () {
      timer = that.data.timer
      if (timer === 1) {
        timer = 0;
        that.setData({
          timer: timer
        })
        console.log("单击"); //双击要执行的事件处理
          innerAudioContext.src = that.data.url21
          innerAudioContext.play();
      }
    }, 250);
    // wx.navigateTo({
    //   url: '../login/login'
    // })
  },
  quxiao(){
        var that = this
        let timer = that.data.timer
        timer++;
        that.setData({
            timer: timer
        })
        if (timer=== 2) {
            timer = 0;
            that.setData({
                timer: timer
            })
            console.log("双击"); //双击要执行的事件处理
            // 音频
            // if (state.number === "") {
            //   // Toast.warn("请输入要去的楼层");
            //   audiodata.url = audiodata.url1;
            //   audiodata.muted = true;
            //   audiodata.autoplay = true;
            //   return false;
            // }
            // 处理
            wx.reLaunch({
                url: '../index/index'
            });
        }
        setTimeout(function () {
            timer = that.data.timer
            if (timer === 1) {
                timer = 0;
                that.setData({
                    timer: timer
                })
                console.log("单击"); //双击要执行的事件处理
                innerAudioContext.src = that.data.url4
                innerAudioContext.play();
            }
        }, 250);
        // wx.navigateTo({
        //   url: '../login/login'
        // })
    },
    quxiaoBack(){
        var that = this
        let timer = that.data.timer
        timer++;
        that.setData({
            timer: timer
        })
        if (timer=== 2) {
            timer = 0;
            that.setData({
                timer: timer
            })
            console.log("双击"); //双击要执行的事件处理
            // 音频
            // if (state.number === "") {
            //   // Toast.warn("请输入要去的楼层");
            //   audiodata.url = audiodata.url1;
            //   audiodata.muted = true;
            //   audiodata.autoplay = true;
            //   return false;
            // }
            // 处理
            wx.navigateBack({
                delta: -1
            });
        }
        setTimeout(function () {
            timer = that.data.timer
            if (timer === 1) {
                timer = 0;
                that.setData({
                    timer: timer
                })
                console.log("单击"); //双击要执行的事件处理
                innerAudioContext.src = that.data.url5
                innerAudioContext.play();
            }
        }, 250);
        // wx.navigateTo({
        //   url: '../login/login'
        // })
    },
})
