const app = getApp();
const util = require('../../utils/util.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
      userInfo:"",
      jueses:['学生','教练','机构'],
      jueseindex: 0,
      account: "",
      nickName: "",
      // 其他信息学员
      avatarUrl: "",
      birthday: "2000-01-01",
      duans:['一段','二段','三段','四段','五段','六段','七段','八段','九段'],
      duanindex: 0,
      card: "",
      education: "",
      sexs:['男','女'],
      sexindex: 0,
      height: "",
      weight: "",
      venue: "",
      school: "",
      classes: "",
      address: "",
      bloodType: "",
      reason: "",
      family_name: "",
      guanxis:['父母','其他'],
      guanxiindex: 0,
      family_workUnit: "",
      family_phone: "",
      jiesongs:['是','否'],
      jiesongindex: 0,
      // 教练
      venues: "",
      teachingYears: "",
      // 机构
      type: "",
      startDate: "2000-01-01",
      code: "",
      contacts: "",
      contactsTitle: "",
      phone: "",
      liansuos:['是','否'],
      liansuoindex: 0,
      siteSize: "",
      coachNum: "",
      studentNum: "",
      email: "",
      introduction: "",
  },
    onLoad: function () {
        var that=this;
        let userInfo = app.globalData.userInfo;
        that.setData({
            userInfo: userInfo,
            nickName: userInfo.nickName,
        })
        // let jueseindex = Number(userInfo.role);
        // if(jueseindex ==0){
        //     that.setData({
        //         userInfo: userInfo,
        //         jueseindex: jueseindex,
        //         account: userInfo.account,
        //         nickName: userInfo.nickName,
        //         avatarUrl: userInfo.avatarUrl,
        //         birthday: userInfo.birthday,
        //         duanindex: Number(userInfo.level),
        //         card: userInfo.card,
        //         education: userInfo.education,
        //         sexindex: Number(userInfo.sex),
        //         height: userInfo.height,
        //         weight: userInfo.weight,
        //         venue: userInfo.venue,
        //         school: userInfo.school,
        //         classes: userInfo.classes,
        //         address: userInfo.address,
        //         bloodType: userInfo.bloodType,
        //         reason: userInfo.reason,
        //         family_name: userInfo.family_name,
        //         guanxiindex: Number(userInfo.family_car),
        //         family_workUnit: userInfo.family_workUnit,
        //         family_phone: userInfo.family_phone,
        //         jiesongindex: Number(userInfo.family_surrogate),
        //     })
        // }
        // if(jueseindex ==1){
        //     that.setData({
        //         userInfo: userInfo,
        //         jueseindex: jueseindex,
        //         account: userInfo.account,
        //         nickName: userInfo.nickName,
        //         avatarUrl: userInfo.avatarUrl,
        //         birthday: userInfo.birthday,
        //         duanindex: Number(userInfo.level),
        //         card: userInfo.card,
        //         education: userInfo.education,
        //         sexindex: Number(userInfo.sex),
        //         height: userInfo.height,
        //         weight: userInfo.weight,
        //         venue: userInfo.venue,
        //         venues: userInfo.venues,
        //         teachingYears: userInfo.teachingYears,
        //     })
        // }
        // if(jueseindex ==2){
        //     that.setData({
        //         userInfo: userInfo,
        //         jueseindex: jueseindex,
        //         account: userInfo.account,
        //         nickName: userInfo.nickName,
        //         avatarUrl: userInfo.avatarUrl,
        //         type: userInfo.type,
        //         startDate: userInfo.startDate,
        //         code: userInfo.code,
        //         contacts: userInfo.contacts,
        //         contactsTitle: userInfo.contactsTitle,
        //         phone: userInfo.phone,
        //         liansuoindex: userInfo.chain,
        //         siteSize: userInfo.siteSize,
        //         coachNum: userInfo.coachNum,
        //         studentNum: userInfo.studentNum,
        //         email: userInfo.email,
        //         introduction: userInfo.introduction,
        //     })
        // }
    },
    inputValue: function (e){
        var that=this;
        var type=e.target.dataset.type;
        var value=e.detail.value;
        // console.log(type)
        // console.log(value)
        // 基本信息
        if(type=="account"){
            that.setData({
                account:value
            })
        }
        if(type=="password"){
            that.setData({
                password:value
            })
        }
        if(type=="nickName"){
            that.setData({
                nickName:value
            })
        }
        // 其他信息
        if(type=="card"){
            that.setData({
                card:value
            })
        }
        if(type=="education"){
            that.setData({
                education:value
            })
        }
        if(type=="height"){
            that.setData({
                height:value
            })
        }
        if(type=="weight"){
            that.setData({
                weight:value
            })
        }
        if(type=="venue"){
            that.setData({
                venue:value
            })
        }
        if(type=="school"){
            that.setData({
                school:value
            })
        }
        if(type=="classes"){
            that.setData({
                classes:value
            })
        }
        if(type=="address"){
            that.setData({
                address:value
            })
        }
        if(type=="bloodType"){
            that.setData({
                bloodType:value
            })
        }
        if(type=="reason"){
            that.setData({
                reason:value
            })
        }
        if(type=="family_name"){
            that.setData({
                family_name:value
            })
        }
        if(type=="family_workUnit"){
            that.setData({
                family_workUnit:value
            })
        }
        if(type=="family_phone"){
            that.setData({
                family_phone:value
            })
        }
        // 教练
        if(type=="venues"){
            that.setData({
                venues:value
            })
        }
        if(type=="teachingYears"){
            that.setData({
                teachingYears:value
            })
        }
        //机构
        if(type=="type"){
            that.setData({
                type:value
            })
        }
        if(type=="code"){
            that.setData({
                code:value
            })
        }
        if(type=="contacts"){
            that.setData({
                contacts:value
            })
        }
        if(type=="contactsTitle"){
            that.setData({
                contactsTitle:value
            })
        }
        if(type=="phone"){
            that.setData({
                phone:value
            })
        }
        if(type=="siteSize"){
            that.setData({
                siteSize:value
            })
        }
        if(type=="coachNum"){
            that.setData({
                coachNum:value
            })
        }
        if(type=="studentNum"){
            that.setData({
                studentNum:value
            })
        }
        if(type=="email"){
            that.setData({
                email:value
            })
        }
        if(type=="introduction"){
            that.setData({
                introduction:value
            })
        }
    },
    bindDateChange: function (e){
        this.setData({
            birthday: e.detail.value
        })
    },
    duanChange: function(e){
        this.setData({
            duanindex: e.detail.value
        })
    },
    sexChange: function(e){
        this.setData({
            sexindex: e.detail.value
        })
    },
    guanxiChange: function(e){
        this.setData({
            guanxiindex: e.detail.value
        })
    },
    jiesongChange: function(e){
        this.setData({
            jiesongindex: e.detail.value
        })
    },
    jigouDateChange: function (e){
        this.setData({
            startDate: e.detail.value
        })
    },
    liansuoChange: function(e){
        this.setData({
            liansuoindex: e.detail.value
        })
    },
    sub: function () {
        var that = this;
        var nickName = that.data.nickName;
        if(nickName == ""){
            wx.showToast({
                title: '昵称不能为空',
                icon: 'none',
                duration: 2000
            })
            return false;
        }
        var accept = {
            id: that.data.userInfo.id,
            nickName: nickName,
        }
        console.log(accept);
        util.request(
            "user/edit.php",
            "POST",
            accept,
            res=> {
                wx.showToast({
                    title: '修改成功',
                    icon: 'success',
                    duration: 2000
                })
                util.request(
                    "user/info.php",
                    "GET",
                    {
                        id: that.data.userInfo.id,
                    },
                    res=> {
                        let userInfo = res.detail.userInfo;
                        app.globalData.userInfo = userInfo;
                        wx.setStorageSync('userInfo', userInfo);
                        setTimeout(function () {
                            wx.navigateBack({
                                delta: -1
                            });
                        },2000)
                    },
                    res=>{}
                )
            },
            res=>{}
        )
        //基本信息
        // var role = Number(that.data.jueseindex);
        // var account = that.data.account;
        // var nickName = that.data.nickName;
        // var accept = {
        //     id: that.data.userInfo.id,
        //     account: account,
        //     role: role,
        //     connect_id: that.data.userInfo.connect_id,
        //     nickName: nickName,
        // }
        // var avatarUrl = that.data.avatarUrl;
        // var birthday = that.data.birthday;
        // var card = that.data.card;
        // var education = that.data.education;
        // var sex = Number(that.data.sexindex);
        // var height = that.data.height;
        // var weight = that.data.weight;
        // var venue = that.data.venue;
        // var school = that.data.school;
        // var classes = that.data.classes;
        // var address = that.data.address;
        // var bloodType = that.data.bloodType;
        // var reason = that.data.reason;
        // var family_name = that.data.family_name;
        // var family_car = Number(that.data.guanxiindex);
        // var family_workUnit = that.data.family_workUnit;
        // var family_phone = that.data.family_phone;
        // var family_surrogate = Number(that.data.jiesongindex);
        //学员
        // if(accept.role === 0){
        //     accept = {
        //         ...accept,
        //         avatarUrl: that.data.avatarUrl,
        //         birthday: that.data.birthday,
        //         level:  Number(that.data.duanindex),
        //         card: that.data.card,
        //         education: that.data.education,
        //         sex: Number(that.data.sexindex),
        //         height: that.data.height,
        //         weight: that.data.weight,
        //         venue: that.data.venue,
        //         school: that.data.school,
        //         classes: that.data.classes,
        //         address: that.data.address,
        //         bloodType: that.data.bloodType,
        //         reason: that.data.reason,
        //         family_name: that.data.family_name,
        //         family_car: Number(that.data.guanxiindex),
        //         family_workUnit: that.data.family_workUnit,
        //         family_phone: that.data.family_phone,
        //         family_surrogate: Number(that.data.jiesongindex),
        //     }
        // }
        // //教练
        // if(accept.role === 1){
        //     accept = {
        //         ...accept,
        //         avatarUrl: that.data.avatarUrl,
        //         birthday: that.data.birthday,
        //         level:  Number(that.data.duanindex),
        //         card: that.data.card,
        //         education: that.data.education,
        //         sex: Number(that.data.sexindex),
        //         height: that.data.height,
        //         weight: that.data.weight,
        //         venue: that.data.venue,
        //         venues: that.data.venues,
        //         teachingYears: Number(that.data.teachingYears),
        //     }
        // }
        // //机构
        // if(accept.role === 2){
        //     accept = {
        //         ...accept,
        //         avatarUrl: that.data.avatarUrl,
        //         type: that.data.type,
        //         code: that.data.code,
        //         address: that.data.address,
        //         contacts: that.data.contacts,
        //         contactsTitle: that.data.contactsTitle,
        //         phone: that.data.phone,
        //         introduction: that.data.introduction,
        //         chain: Number(that.data.liansuoindex),
        //         siteSize: that.data.siteSize,
        //         coachNum: that.data.coachNum,
        //         studentNum: that.data.studentNum,
        //         email: that.data.email,
        //         startDate: that.data.startDate,
        //     }
        // }
    },
})
