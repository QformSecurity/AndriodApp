const app = getApp();
const util = require('../../utils/util.js');
let innerAudioContext = wx.createInnerAudioContext();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    number: '',
      zuobiao: {

      },
    timer: 0,
      appUrl:  app.globalData.url,
      url20: "",
      url21: "",
      url: '',
      url1: "",
      url2: "",
      url3: "",
      url4: "",
      url5: "",
  },
  onLoad:function(){
      this.setData({
          number: app.dataSource.number,
          zuobiao: app.dataSource.zuobiao
      })
      this.setData({
          number: app.dataSource.number,
          url1: app.globalData.url + "assets/page04/您要去往的楼层按钮位置是第.mp3",
          url2: app.globalData.url + "assets/page04/行.mp3",
          url3: app.globalData.url + "assets/page04/列.mp3",
          url4: app.globalData.url + "assets/page04/我已按好.mp3",
          url5: app.globalData.url + "assets/page04/上一步.mp3",
      })
      innerAudioContext.src = this.data.url1
      innerAudioContext.play();
      let url20 = "";
      let url21 = "";
      let url20s = false
      let url21s = false
      for (let i=0;i<app.dataSource.numberList2.length;i++){
          if(app.dataSource.zuobiao.line === app.dataSource.numberList2[i].num){
              url20 =app.globalData.url +app.dataSource.numberList2[i].url
              url20s = true
          }
          if(app.dataSource.zuobiao.row === app.dataSource.numberList2[i].num){
              url21 = app.globalData.url +app.dataSource.numberList2[i].url
              url21s = true
          }
      }
      this.setData({
          url20: url20,
          url21: url21,
      })
      let that = this
      if(url20s === true){
          setTimeout(function (){
              innerAudioContext.src = url20
              innerAudioContext.play();
              setTimeout(function (){
                  innerAudioContext.src = that.data.url2
                  innerAudioContext.play();
                  if(url21s === true){
                      setTimeout(function (){
                          innerAudioContext.src = url21
                          innerAudioContext.play();
                          setTimeout(function (){
                              innerAudioContext.src = that.data.url3
                              innerAudioContext.play();
                          }, 1000)
                      },1000)
                  }
              }, 1000)
          },4000)
      }
 },
  onShow: function () {
    },
  onReady(){
    // console.log(11)
  },
  onHide(){
    // console.log(11)

  },
  queren(){
    var that = this
    let timer = that.data.timer
    timer++;
    that.setData({
      timer: timer
    })
    if (timer=== 2) {
      timer = 0;
      that.setData({
        timer: timer
      })
      console.log("双击"); //双击要执行的事件处理
      // 音频
      // if (state.number === "") {
      //   // Toast.warn("请输入要去的楼层");
      //   audiodata.url = audiodata.url1;
      //   audiodata.muted = true;
      //   audiodata.autoplay = true;
      //   return false;
      // }
      // 处理
        wx.navigateTo({
            url: '../five/five'
        })
    }
    setTimeout(function () {
      timer = that.data.timer
      if (timer === 1) {
        timer = 0;
        that.setData({
          timer: timer
        })
        console.log("单击"); //双击要执行的事件处理
          innerAudioContext.src = that.data.url4
          innerAudioContext.play();
      }
    }, 250);
    // wx.navigateTo({
    //   url: '../login/login'
    // })
  },
    quxiaoBack(){
        var that = this
        let timer = that.data.timer
        timer++;
        that.setData({
            timer: timer
        })
        if (timer=== 2) {
            timer = 0;
            that.setData({
                timer: timer
            })
            console.log("双击"); //双击要执行的事件处理
            // 音频
            // if (state.number === "") {
            //   // Toast.warn("请输入要去的楼层");
            //   audiodata.url = audiodata.url1;
            //   audiodata.muted = true;
            //   audiodata.autoplay = true;
            //   return false;
            // }
            // 处理
            wx.navigateBack({
                delta: -1
            });
        }
        setTimeout(function () {
            timer = that.data.timer
            if (timer === 1) {
                timer = 0;
                that.setData({
                    timer: timer
                })
                console.log("单击"); //双击要执行的事件处理
                innerAudioContext.src = that.data.url5
                innerAudioContext.play();
            }
        }, 250);
        // wx.navigateTo({
        //   url: '../login/login'
        // })
    },
})
