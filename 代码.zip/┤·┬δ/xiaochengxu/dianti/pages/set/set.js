const app = getApp();
const util = require('../../utils/util.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
      userInfo: null,
      imgUr: app.globalData.imgUr,
      jueses:['','学生','教练','机构'],
      roleName: "",
      duans:['一级','二级','三级','四级','五级','六级','七级','八级','九级','十级','一段','二段','三段','四段','五段','六段','七段','八段','九段'],
      levelName: "",
      sexs:['男','女'],
      sexsName: "",
      educationData: ['幼儿园','小学','初中','高中','大专','本科','研究生','博士生'],
      educationName: '',
      bloodTypeData: ['A','B','O','AB'],
      bloodTypeName: '',
      guanxis:['父母','其他'],
      family_carName: "",
      jiesongs:['是','否'],
      family_surrogateName: "",
      liansuos:['是','否'],
      chainName: "",
      // phone:'',
      // isShow: false
  },
    onShow: function () {
      var that=this;
        let userInfo = app.globalData.userInfo;
        console.log(userInfo)
        let roleName = "";
        if(userInfo.role){
            roleName = that.data.jueses[Number(userInfo.role)]
        }
        let levelName = "";
        if(userInfo.level){
            levelName = that.data.duans[Number(userInfo.level)]
        }
        let sexsName = "";
        if(userInfo.sex){
            sexsName = that.data.sexs[Number(userInfo.sex)]
        }
        let educationName = "";
        if(userInfo.education){
            educationName = that.data.educationData[Number(userInfo.education)]
            userInfo.educationName = educationName
        }
        let bloodTypeName = "";
        if(userInfo.bloodType){
            bloodTypeName = that.data.bloodTypeData[Number(userInfo.bloodType)]
            userInfo.bloodTypeName = bloodTypeName
        }
        let family_carName= "";
        if(userInfo.family_car){
            family_carName = that.data.guanxis[Number(userInfo.family_car)]
        }
        let family_surrogateName = "";
        if(userInfo.family_surrogate){
            family_surrogateName = that.data.jiesongs[Number(userInfo.family_surrogate)]
        }
        let chainName = "";
        if(userInfo.chain){
            chainName = that.data.liansuos[Number(userInfo.chain)]
        }
        let keys = Object.keys(userInfo)
        for (let i=0;i<keys.length;i++){
            if(userInfo[keys[i]] == 'null'){
                userInfo[keys[i]] = ""
            }
        }
        // console.log(userInfo);
        that.setData({
            userInfo: userInfo,
            roleName: roleName,
            levelName: levelName,
            sexsName:sexsName,
            family_carName: family_carName,
            family_surrogateName: family_surrogateName,
            chainName: chainName,
        })
      // var phone='';
      // let userInfo = null
      // if(app.globalData.userInfo!=null){
      //     userInfo = app.globalData.userInfo
      //     phone=app.globalData.userInfo.telephone;
      // }
      // if(phone=='' || phone==null){
      //    phone='前往关联手机号'
      // }
    },
    changeAccount(){
        wx.navigateTo({
            url: '../bindAccount/bindAccount'
        })
    },
    edit:function (){
        wx.navigateTo({
            url: '../accountChange/accountChange?accountStatue=1'
        })
    },
    pwdChange(){
        wx.navigateTo({
            url: '../pwdChange/pwdChange?type=1'
        })
    },
    tuichu:function(){
        wx.showModal({
            title: '提示',
            content: '确认退出吗？',
            success (res) {
                if (res.confirm) {
                    app.globalData.userInfo = null;
                    wx.setStorageSync('userInfo', null);
                    // wx.reLaunch({
                    //     url: '../login/login'
                    // })
                    wx.switchTab({
                        url: '../index/index'
                    })
                }
            }
        })
    },
})
