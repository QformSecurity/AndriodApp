const app = getApp();
const util = require('../../utils/util.js');
let innerAudioContext = wx.createInnerAudioContext();
innerAudioContext.autoplay = true
Page({
  /**
   * 页面的初始数据
   */
  data: {
      appurls: app.globalData.urls,
    number: '',
    timer: 0,
      appUrl:  app.globalData.url,
      url1: "",
      url2: "",
      url3: "",
      numberList: [],
      numberList2: [],
  },
  onLoad:function(){
      let numberList = [];
      let numberListK = {};
      for (let i = 0; i < 32; i++) {
          numberListK = {};
          if (i < 31) {
              numberListK = {
                  num: i,
                  url: "assets/shuzi/" + i + "层.mp3",
              };
          }
          if (i === 31) {
              numberListK.num = "未知";
              numberListK.url = "assets/shuzi/未知.mp3";
          }
          numberList.push(numberListK);
      }
      app.dataSource.numberList = numberList;
      let numberList2 = [];
      let numberListK2 = {};
      for (let i = 0; i < 11; i++) {
          numberListK = {};
          if (i < 10) {
              numberListK2 = {
                  num: i,
                  url: "assets/shuzi/" + i + ".mp3",
              };
          }
          if (i === 10) {
              numberListK2.num = "未知";
              numberListK2.url = "assets/shuzi/未知.mp3";
          }
          numberList2.push(numberListK2);
      }
      app.dataSource.numberList2 = numberList2;
      this.setData({
          numberList: numberList,
          numberList2: numberList2,
      })
      // this.setData({
      //     url: '../assets/page04/您要去往的楼层按钮位置是第.mp3'
      // })
      // this.audioCtx.play()
      this.setData({
          url1: this.data.appUrl + "assets/page01/请输入您想要去往的楼层.mp3",
          url2: this.data.appUrl + "assets/page01/确认.mp3",
          url3: this.data.appUrl + "../assets/page01/请输入.mp3",
      })
      innerAudioContext.src = this.data.url1
      console.log( this.data.url1)
      innerAudioContext.play();
      // 获取token
      wx.request({
          // 必需
          url: app.globalData.urls+'oauth/2.0/token',
          data: {
              grant_type: 'client_credentials',
              client_id: 'yIs67fP0zsdm1GzvUpYUYtS8',
              client_secret: 'pYZxcKkdbEiRKImQEjg2CI7qH2K1aUpH',
          },
          method:"POST",
          header: {
              'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
          },
          success: function (res) {
              // console.log(res)
              app.globalData.access_token = res.data.access_token
              // console.log(app.globalData.access_token)
          },
      })
 },
  onShow: function () {
    },
    onReady: function (e) {
        //创建内部 audio 上下文 InnerAudioContext 对象。

        // this.innerAudioContext = wx.createInnerAudioContext();
        // this.innerAudioContext.src = this.data.url
        // this.innerAudioContext.play();
    },
  onHide(){
    // console.log(11)

  },
    inputFoce(){
        innerAudioContext.src = this.data.url3
        innerAudioContext.play();
    },
  inputValue: function (e){
        var that=this;
        var value=e.detail.value;
      that.setData({
          number:value
      })
    },
  queren(){
    var that = this
    let timer = that.data.timer
    timer++;
    that.setData({
      timer: timer
    })
    if (timer=== 2) {
      timer = 0;
      that.setData({
        timer: timer
      })
      console.log("双击"); //双击要执行的事件处理
      // 音频
      // if (state.number === "") {
      //   // Toast.warn("请输入要去的楼层");
      //   audiodata.url = audiodata.url1;
      //   audiodata.muted = true;
      //   audiodata.autoplay = true;
      //   return false;
      // }
      // 处理
      app.dataSource.number = that.data.number
        wx.navigateTo({
            url: '../about/about'
        })
    }
    setTimeout(function () {
      timer = that.data.timer
      if (timer === 1) {
        timer = 0;
        that.setData({
          timer: timer
        })
        console.log("单击"); //双击要执行的事件处理
          innerAudioContext.src = that.data.url2
          innerAudioContext.play();
      }
    }, 250);
    // wx.navigateTo({
    //   url: '../login/login'
    // })
  },
    onShareAppMessage: function (res) {
        var that=this;
        if (res.from === 'button') {
            console.log(res.target);
            /*
            //获取优惠券

            setTimeout(function () {
                wx.showToast({
                    title: '分享成功，得到一张优惠券，可前往我的优惠券进行查看',
                    icon: 'none',
                    duration: 2000
                })
            },3000)
            */

        }
        return {
            title: 'LIFT ME UP',
            path: '/pages/index/index',
            // imageUrl:that.data.imgUrl + that.data.shopData.fileList,
            success: function (res) {
                console.log('成功', res);
                wx.showToast({
                    title: '分享成功',
                    icon: 'success',
                    duration: 2000
                })
            }
        }
    },
    onShareTimeline: function () {
        //console.log("分享到朋友圈");
        var that=this;
        return {
            title: "LIFT ME UP",
            // path: '/pages/shopContents/shopContents?qiye='+that.data.qiye + '&&id='+shopData.id+ '&&shareId='+shareId +"&&prevShareId=" +prevShareId,
            path: '/pages/index/index',
            // imageUrl:that.data.imageUrl + "login1.jpg",
        };
    },

})
