import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "@nutui/nutui/dist/style.css";
import { Button, Input, Uploader, Audio } from "@nutui/nutui";

createApp(App).use(store).use(router)
  .use(Input)
  .use(Button)
  .use(Uploader)
  .use(Audio)
  .mount("#app");
