import { Toast } from "@nutui/nutui";
import store from "@/store";
export default {
  // 图片识别
  shibie(number,result){
    let results = result
    let result_num = results.words_result_num;
    let total_high = 0
    let zuobiao = {
      row: 0,
      line: 0,
    }
    let scan_row = 0
    let scan_line = 0
    let average_high = 0
    let average_high_err = 0
    let words_result = results.words_result
    if (result_num > 0){
      for(let i=0;i<words_result.length;i++){
        total_high = total_high + words_result[i].location.height;
      }
      average_high = total_high / result_num;
      average_high_err = average_high * 0.2;
      let Key_Num_Value = []
      let Row = []
      let Line = []
      Key_Num_Value[0] = words_result[0].words;
      Row[0] = 0;
      Line[0] = 0;
      let last_key_top = words_result[0].location.top;
      for(let i=1;i<words_result.length;i++) {
        let current_top = words_result[i].location.top;
        if (last_key_top - average_high_err <= current_top && current_top <= last_key_top + average_high_err) {
          Line[i] = Line[i - 1]
          Row[i] = Row[i - 1] + 1
        } else {
          Line[i] = Line[i - 1] + 1
          Row[i] = 0
        }
        Key_Num_Value[i] = words_result[i].words
        last_key_top = current_top
      }
      for(let i=0;i<Key_Num_Value.length;i++) {
        if(number == Key_Num_Value[i]){
          scan_row = Row[i] + 1
          scan_line = Line[i] + 1
        }
      }
    }
    zuobiao.row = scan_row
    zuobiao.line = scan_line
    return zuobiao
  },
  shibie2(result){
    let results = result
    let result_num = results.words_result_num;
    let zuobiao = {
      info: '',
      number: '',
    }
    let max_size = 0
    let max_word_id = ""
    let words_result = results.words_result
    if (result_num > 0){
      for(let i=0;i<words_result.length;i++){
        let size = words_result[i].location.height * words_result[i].location.width
        if(size>max_size){
          max_size = size
          max_word_id = i
        }
      }
      zuobiao.info = words_result[max_word_id].words
    }
    return zuobiao
  },
  //图片转base64
  getBase64(file) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader()
      let imgResult = ''
      reader.readAsDataURL(file)
      reader.onload = function () {
        imgResult = reader.result
      }
      reader.onerror = function (error) {
        reject(error)
      }
      reader.onloadend = function () {
        resolve(imgResult)
      }
    })
  },
  // base64转文件
  base64ToFile(urlData, fileName) {
    let arr = urlData.split(",");
    let mime = arr[0].match(/:(.*?);/)[1];
    let bytes = atob(arr[1]); // 解码base64
    let n = bytes.length;
    let ia = new Uint8Array(n);
    while (n--) {
      ia[n] = bytes.charCodeAt(n);
    }
    return new File([ia], fileName, { type: mime });
  },
  GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg); // search,查询？后面的参数，并匹配正则
    console.log(r);
    if (r != null) return unescape(r[2]);
    return null;
  },
  getLocalTimes(nS) {
    var that = this;
    // return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
    var time = new Date(parseInt(nS) * 1000);
    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mm = time.getMinutes();
    var s = time.getSeconds();
    var data = {
      y: y,
      m: that.add0(m),
      d: that.add0(d),
      h: that.add0(h),
      mm: that.add0(mm),
      s: that.add0(s),
    };
    return data;
  },
  // 时间转换，
  add0(m) {
    return m < 10 ? "0" + m : m;
  },
  // 压缩图片
  photoCompress(file, objCompressed, objDiv) {
    var that = this;
    var ready = new FileReader();
    ready.readAsDataURL(file);
    ready.onload = function () {
      var fileResult = this.result;
      that.canvasDataURL(fileResult, objCompressed, objDiv);
    };
  },
  canvasDataURL(path, objCompressed, callback) {
    var img = new Image();
    img.src = path;
    img.onload = function () {
      var that = this;
      // 默认压缩后图片规格
      var quality = 0.5;
      var w = that.width;
      var h = that.height;
      var scale = w / h;
      // 实际要求
      w = objCompressed.width || w;
      h = objCompressed.height || w / scale;
      if (
        objCompressed.quality &&
        objCompressed.quality > 0 &&
        objCompressed.quality <= 1
      ) {
        quality = objCompressed.quality;
      }

      // 生成canvas
      var canvas = document.createElement("canvas");
      var ctx = canvas.getContext("2d");
      // 创建属性节点
      var anw = document.createAttribute("width");
      anw.nodeValue = w;
      var anh = document.createAttribute("height");
      anh.nodeValue = h;
      canvas.setAttributeNode(anw);
      canvas.setAttributeNode(anh);
      ctx.drawImage(that, 0, 0, w, h);

      var base64 = canvas.toDataURL("image/jpeg", quality);
      // 回调函数返回base64的值
      callback(base64);
    };
  },
  canvasDataURL2(path,callback) {
    var img = new Image();
    img.src = path;
    img.onload = function(){
      var that = this;
      // 默认按比例压缩
      // var bili = that.width / that.height
      // console.log(bili)
      var w = that.width * 0.1
      var h = that.height * 0.1
      // var w = 150;
      // var h = parseInt(150 * that.height / that.width);
      // console.log(w)
      // console.log(h)
      var quality = 0.7  // 默认图片质量为0.7
      //生成canvas
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');
      // 创建属性节点
      var anw = document.createAttribute("width");
      anw.nodeValue = w;
      var anh = document.createAttribute("height");
      anh.nodeValue = h;
      canvas.setAttributeNode(anw);
      canvas.setAttributeNode(anh);
      ctx.drawImage(that, 0, 0, w, h);
      // quality值越小，所绘制出的图像越模糊
      ////console.log(quality);
      var base64 = canvas.toDataURL('image/jpeg', quality);
      // console.log(showSize(base64) + 'kb')
      // function showSize(base64url) {
      //   //把头部去掉
      //   var str = base64url.replace('data:image/jpeg;base64,', '');
      //   // 找到等号，把等号也去掉
      //   var equalIndex = str.indexOf('=');
      //   if(str.indexOf('=')>0) {
      //     str=str.substring(0, equalIndex);
      //   }
      //   // 原来的字符流大小，单位为字节
      //   var strLength=str.length;
      //   // 计算后得到的文件流大小，单位为字节
      //   var fileLength=parseInt(strLength-(strLength/8)*2);
      //   // 由字节转换为kb
      //   var size = "";
      //   size = (fileLength / 1024).toFixed(2);
      //   var sizeStr = size + ""; //转成字符串
      //   var index = sizeStr.indexOf("."); //获取小数点处的索引
      //   var dou = sizeStr.substr(index + 1, 2) //获取小数点后两位的值
      //   if (dou == "00") { //判断后两位是否为00，如果是则删除00
      //     return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2)
      //   }
      //   return size;
      // }
      // 回调函数返回base64的值
      callback(base64);
    }
  },
  canvasDataURL3(path, callback) {
    var img = new Image();
    img.src = path;
    img.onload = function () {
      var that = this;
      // 默认压缩后图片规格
      var quality = 0.5;
      var w = that.width *0.1;
      var h = that.height *0.1;

      // 生成canvas
      var canvas = document.createElement("canvas");
      var ctx = canvas.getContext("2d");
      // 创建属性节点
      var anw = document.createAttribute("width");
      anw.nodeValue = w;
      var anh = document.createAttribute("height");
      anh.nodeValue = h;
      canvas.setAttributeNode(anw);
      canvas.setAttributeNode(anh);
      ctx.drawImage(that, 0, 0, w, h);

      var base64 = canvas.toDataURL("image/jpeg", quality);
      // 回调函数返回base64的值
      callback(base64);
    };
  },
  //清除历史记录
  huituis() {
    history.pushState(null, null, document.URL);
    window.addEventListener("popstate", function () {
      history.pushState(null, null, document.URL);
    });
  },
  // 物理退出
  shutdown() {
    document.addEventListener(
      "backbutton",
      function (e) {
        console.log(e);
        if (store.state.exitcode === 0) {
          store.state.exitcode++;
          Toast.text("再点一次退出");
          setTimeout(function () {
            store.state.exitcode = 0;
          }, 2000);
        } else if (store.state.exitcode === 1) {
          navigator.app.exitApp(); //退出app
          // Dialog({
          //   title: "提示",
          //   content: "确定退出平台吗",
          //   onOk() {
          //     navigator.app.exitApp(); //退出app
          //   },
          //   onCancel() {
          //     that.exitAppTicker = 0;
          //   },
          // });
        }
        // if (this.isHomePage()) {
        // } else {
        //   // history.back();
        // }
      },
      false
    );
  },
};
