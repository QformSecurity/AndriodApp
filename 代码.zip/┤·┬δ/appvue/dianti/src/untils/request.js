import axios from "axios";
import store from "@/store";
import qs from "qs";
import { Toast } from "@nutui/nutui";
import router from "@/router";
// 创建axios实例
var service = axios.create({
  // baseURL: "http://xinagri.com/MinSystemAdmin/action/",
  // baseURL: "http://localhost:8081",
  // baseURL: "http://8.142.74.18:6084",
  // baseURL: "http://192.168.50.244:8081",
  // baseURL: 'http://localhost:8081/artemis/api/',
  // baseURL: 'http://192.168.180.156:8080/app/',
  // baseURL: 'http://192.168.50.244/artemis/api/',
  // baseURL: "https://fenglinvistor.xinagri.com/fenglinvistor/artemis/api/",
  // baseURL: 'http://localhost:8081/artemis/api/',
  // baseURL: 'http://localhost/fenglinvistor/artemis/api/',
  // baseURL: "http://localhost:8090/artemis/api/",
  // baseURL: "http://39.103.197.124:99/artemis/api/",
  // baseURL: "http://192.168.50.244/xf-service/",
  // baseURL: "http://visitor.zhihuifenglin.com/fenglinvisitor/artemis/api/",
  timeout: 5000,
});
service.interceptors.response.use(
  (response) => {
    // console.log('拦截器响应成功')
    // console.log(response)
    // var code = response.data.code
    // console.log(code)
    // if (code === 200) {}
    // return response.data;
    // console.log(response)
    // console.log(response.data)
    return response.data;
    // if (response.data.message === "token is expired" || response.data.code === 41004) {
    //   Toast.fail("登录失效，请重新登录");
    //   // let that = this;
    //   setTimeout(function () {
    //     localStorage.removeItem("token");
    //     router.push({
    //       name: "Login",
    //     });
    //     // window.location.reload();
    //   }, 2000);
    // } else if (response.data.code === 20000 || response.data.code === 50000) {
    //   // console.log(response.data.data)
    //   // return response.data.data;
    //   if (response.data.data) {
    //     return response.data.data;
    //   } else {
    //     return response.data;
    //   }
    // } else {
    //   Toast.fail(response.data.message);
    //   return null;
    // }
  },
  (error) => {
    console.log("拦截器响应失败");
    console.log(error);
    if (error.request) {
      console.log(error.request);
    } else if (error.response) {
      console.log(error.response.data);
      console.log(error.response.status);
    }
    if (error && error.response) {
      switch (error.response.status) {
        case 400:
          error.message = "请求错误(400)";
          break;
        case 401:
          error.message = "未授权，请重新登录(401)";
          break;
        case 403:
          error.message = "拒绝访问(403)";
          break;
        case 404:
          error.message = "请求出错(404)";
          break;
        case 408:
          error.message = "请求超时(408)";
          break;
        case 500:
          error.message = "服务器错误(500)";
          break;
        case 501:
          error.message = "服务未实现(501)";
          break;
        case 502:
          error.message = "网络错误(502)";
          break;
        case 503:
          error.message = "服务不可用(503)";
          break;
        case 504:
          error.message = "网络超时(504)";
          break;
        case 505:
          error.message = "HTTP版本不受支持(505)";
          break;
      }
      Toast.fail(error.message);
    }
    // 网络
    let networkState = navigator.connection.type;
    // Toast.text(networkState);
    if (networkState === "none") {
      Toast.fail("网络未连接，请稍后重试");
    }
    // return error.message;
  }
);
// var token = localStorage.getItem("token");
// var token = localStorage.getItem("token");
// console.log(token)
export default {
  service,
  // 登录
  login(url, params) {
    return service({
      url: url,
      method: "POST",
      data: params, // 向服务端传值
      headers: {
        "Content-Type": "application/json",
      },
    });
  },
  // strong请求
  strongGet(url) {
    return service({
      url: url,
      method: "get",
      headers: {
        "Content-Type": "application/json",
        authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
  },
  strongPost(url, data) {
    return service({
      url: url,
      method: "post",
      headers: {
        "Content-Type": "application/json",
        authorization: "Bearer " + localStorage.getItem("token"),
      },
      data,
    });
  },
  strongPut(url) {
    return service({
      url: url,
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
  },
  strongPut2(url, data) {
    return service({
      url: url,
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        authorization: "Bearer " + localStorage.getItem("token"),
      },
      data,
    });
  },
  strongProfile(url,headers) {
    return service({
      url: url,
      method: "get",
      headers: headers,
    });
  },
  // get请求
  get(url, params) {
    return service({
      url: url,
      method: "get",
      params: params, // 向服务端传值
      // headers: {
      //   'Content-Type': 'application/json;charset=utf-8'
      // }
    });
  },
  // post请求
  post(url, params) {
    // console.log(store.state.token);
    var k = {
      version: "1.0",
      command: params.command,
      token: store.state.token,
      content: params.content,
    };
    // console.log(k);
    return service({
      url: url,
      method: "POST",
      data: k, // 向服务端传值
      headers: {
        "Content-Type": "application/json",
      },
    });
  },
  // 自定义post
  changePost(url, params) {
    return service({
      url: url,
      method: "POST",
      data: params, // 向服务端传值
      headers: {
        "Content-Type": "application/json",
      },
    });
  },
  changePost2(url, params) {
    return service({
      url: url,
      method: "POST",
      data: qs.stringify(params), // 向服务端传值
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });
  },
  // 物理硬件
  internet() {
    let networkState = navigator.connection.type;
    // Toast.text(networkState);
    if (networkState === "none") {
      Toast.text("网络未连接，请稍后重试");
    }
    // return networkState;
  },
  // changePost (url, headers, params) {
  //   var headers1 = {
  //     'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
  //     'X-Ca-Key': '29077365',
  //     'X-Ca-Signature': 'VZm8axQMyHYHSZk8JtQixfW0XbWTcjVV1aSwv0AnM28=',
  //     'X-Ca-Signature-Headers': 'x-ca-key'
  //   }
  //   return service({
  //     url: url,
  //     method: 'POST',
  //     data: qs.stringify(params), // 向服务端传值
  //     headers: Object.assign(headers1, headers)
  //   })
  // }
};
