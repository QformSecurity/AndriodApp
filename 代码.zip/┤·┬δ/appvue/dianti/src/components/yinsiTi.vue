<template>
  <div class="container">
    <div class="yinsi-modal" v-if="yinsiStatue === true">
      <div  class="yinsi-modal-box">
        <div class="yinsi-modal-box-header">
          用户隐私政策
        </div>
        <div class="yinsi-modal-box-content">
          <div class="yinsi-text">
            <strong>《LiftMeUp隐私政策》</strong>
            <br>【生效时间】：2023-12-03
            <br>【更新时间】：2023-12-03
            <br>1.隐私政策
            <br>【LiftMeUp】的服务提供者为【薛明勋】
            <br>尊重并保护所有使用服务用户的个人隐私权。 除本隐私权政策另有规定外，在未征得您事先许可的情 况下，LiftMeUp不会将这些信息对外披露或向第三方提 供。LiftMeUp会不时更新本隐私权政策。
            您在同意 LiftMeUp服务使用协议之时，即视为您已经同意本隐私 权政策全部内容。本隐私权政策属于LiftMeUp服务使用 协议不可分割的一部分。
            <br> <strong>1. 适用范围</strong>
            <br>(a) 在您使用LiftMeUp网络服务，或访问LiftMeUp平台 网页时，LiftMeUp<strong>自动接收并记录的您的浏览器和计算机上的信息，包括但不限于您的IP地址、浏览器的类型、使用的语言、访问日期和时间、软硬件特征信息及 您需求的网页记录等数据；</strong> 您了解并同意，以下信息不适用本隐私权政策：
            <br>(b) LiftMeUp收集到的您在LiftMeUp发布的有关信息数据；
            <br> (b) 违反法律规定或违反LiftMeUp规则行为及LiftMeUp 已对您采取的措施。
            <br> <strong>2. 信息使用</strong>
            <br>(a)	LiftMeUp不会向任何无关第三方提供、出售、出 租、分享或交易您的个人信息，除非事先得到您的许可，或该第三方和LiftMeUp（含LiftMeUp关联公司）单 独或共同为您提供服务，且在该服务结束后，其将被禁 止访问包括其以前能够访问的所有这些资料。
            <br>(b)	LiftMeUp亦不允许任何第三方以任何手段收集、编辑、出售或者无偿传播您的个人信息。任何LiftMeUp平 台用户如从事上述活动，一经发现，LiftMeUp有权立即 终止与该用户的服务协议。
            <br><strong>3. 信息披露</strong>
            <br>在如下情况下，LiftMeUp将依据您的个人意愿或法律的 规定全部或部分的披露您的个人信息：
            <br>(a) 经您事先同意，向第三方披露；
            <br>(b) 为提供您所要求的产品和服务，而必须和第三方分 享您的个人信息；
            <br>(c) 根据法律的有关规定，或者行政或司法机构的要 求，向第三方或者行政、司法机构披露；
            <br>(d) 如您出现违反中国有关法律、法规或者LiftMeUp服 务协议或相关规则的情况，需要向第三方披露；
            <br>(e) 如您是适格的知识产权投诉人并已提起投诉，应被 投诉人要求，向被投诉人披露，以便双方处理可能的权 利纠纷；
            <br>(f) 在LiftMeUp平台上创建的某一交易中，如交易任何 一方履行或部分履行了交易义务并提出信息披露请求 的，LiftMeUp有权决定向该用户提供其交易对方的联络 方式等必要信息，以促成交易的完成或纠纷的解决。
            <br>(g) 其它LiftMeUp根据法律、法规或者网站政策认为合 适的披露。
            <br><strong>4. 信息存储和交换</strong>
            <br>LiftMeUp收集的有关您的信息和资料将保存在LiftMeUp 及（或）其关联公司的服务器上，这些信息和资料可能传送至您所在国家、地区或LiftMeUp收集信息和资料所在地的境外并在境外被访问、存储和展示。
            <br><strong>5. 采集图片的使用</strong>
            <br>(a) 在您未拒绝接受<strong>“采集图片”</strong>的情况下，<strong>LiftMeUp会在您的手机上设定或取用拍摄的图片。</strong>
            <br>(b) 您有权选择接受或拒绝接受<strong>“采集图片”</strong>。您可以通过修改程序设置的方式拒绝<strong>“采集图片”</strong>。但如果您选择 拒绝<strong>“采集图片”</strong>，则您可能无法登录或使用依赖于“采集图片”为核心的LiftMeUp服务或功能。
            <br>(c) 通过LiftMeUp所采集的图片，所取得的有关信息， 将适用本政策。
            <br> <strong>6. 信息安全</strong>
            <br>(a) LiftMeUp帐号均有安全保护功能，请妥善保管您的 用户名及密码信息。LiftMeUp将通过对用户密码进行加 密等安全措施确保您的信息不丢失，不被滥用和变造。 尽管有前述安全措施，但同时也请您注意在信息网络上 不存在“完善的安全措施”。
            <br>(b) 在使用LiftMeUp网络服务进行网上交易时，您不可 避免的要向交易对方或潜在的交易对
            <br><strong>7. 本隐私政策的更改</strong>
            <br>(a)	如果决定更改隐私政策，我们会在本政策中、本公 司网站中以及我们认为适当的位置发布这些更改，以便 您了解我们如何收集、使用您的个人信息，哪些人可以 访问这些信息，以及在什么情况下我们会透露这些信息。
            <br>(b)	本公司保留随时修改本政策的权利，因此请经常查看。如对本政策作出重大更改，本公司会通过网站通知的形式告知。请您妥善保护自己的个人信息，仅在必要的情形下向他 人提供。
            <br>2.	服务条款 软件服务及隐私条款 欢迎您使用软件及服务，以下内容请仔细阅读。
            <br>1、保护用户个人信息是一项基本原则，我们将会采取 合理的措施保护用户的个人信息。除法律法规规定的情 形外，未经用户许可我们不会向第三方公开、透漏个人信息。APP对相关信息采用专业加密存储与传输方式，保障用户个人信息安全，如果您选择同意使用APP软件，即表示您认可并接受APP服务条款及其可能随时更新的内容。
            <br>2、我们将会使用您的以下功能：<strong>麦克风、喇叭、WIFI 网络、蜂窝通信网络，</strong>如果您禁止APP使用以上相关服务和功能，您将自行承担不能获得或享用APP相应服务的后果。
            <br>3、为了能够让APP定位服务更精确，可能会收集并处理有关<strong>您实际所在位置信息（例如移动设备发送的GPS信 号），WI‐FI接入点和 基站位置信息。</strong>我们将对上述信息实施技术保护措施，以最大程度保护这些信息不被第 三方非法获得，同时，您可以自行选择拒绝我们基于技术必要性 收集的这些信息，并自行承担不能获得或享 用APP相应服务的后果。
            <br>4、由于您的自身行为或不可抗力等情形，导致上述可 能涉及您隐私或您认为是私人信息的内容发生被泄露、批漏，或被第三方获取、使用、转让等情形的，均由您 自行承担不利后果，我们对此不承担任何责任。
            <br>5、我们拥有对上述条款的最终解释权，如有疑问，可发邮件给我们：<strong>xuems201@163.com</strong>，我们将在<strong>5</strong>个工作日内回复您。
          </div>
        </div>
        <div class="yinsi-modal-box-bottom">
          <div class="yinsi-modal-box-bottom-btn1" @click="quxiaoClick">
            关闭
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
// import { toRefs } from "vue";

export default {
  name: "HelloWorld",
  props: {
    yinsiStatue: Boolean,
  },
  setup(props,context) {
    const quxiaoClick = () =>{
      context.emit("quxiaoClick")
    }
    return {
      quxiaoClick,
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@import "../untils/common.css";
.yinsi-modal{
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: 10;
  top: 0;
  left: 0;
  background: rgb(0,0,0, 0.2);
}
.yinsi-modal-box{
  width: 80%;
  margin: 40% 10% 0 10%;
  height: 4rem;
  background-color: #f5f5f5;
  border-radius: 10px 10px;
  position: relative;
  overflow: hidden;
}
.yinsi-modal-box-header{
  width: 100%;
  height: 0.5rem;
  line-height: 0.5rem;
  background-color: white;
  position: absolute;
  top: 0;
  font-size: 0.2rem;
  text-align: center;
}
.yinsi-modal-box-content{
  width: 100%;
  height: 3rem;
  overflow-x: hidden;
  overflow-y: scroll;
  margin: 0.5rem 0;
}
.yinsi-text {
  width: 80%;
  margin: 0.1rem 10%;
  padding: 0.1rem 0;
  font-size: 0.14rem;
  color: #262626;
}
.yinsi-modal-box-bottom{
  width: 100%;
  height: 0.5rem;
  line-height: 0.5rem;
  background-color: white;
  position: absolute;
  bottom: 0;
  display: flex;
  justify-content: space-around;
  align-content: center;
}
.yinsi-modal-box-bottom-btn1{
  width: 40%;
  text-align: center;
  height: 0.36rem;
  line-height: 0.36rem;
  font-size: 0.14rem;
  color: #262626;
  border: #262626 1px solid;
  border-radius: 10px 10px;
  margin: auto 0;
}
.yinsi-modal-box-bottom-btn2{
  width: 40%;
  margin: auto 0;
  text-align: center;
  height: 0.36rem;
  line-height: 0.36rem;
  font-size: 0.16rem;
  color: white;
  background-color: #262626;
  border-radius: 10px 10px;
}
</style>
