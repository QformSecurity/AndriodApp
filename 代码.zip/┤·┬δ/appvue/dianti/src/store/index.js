import { createStore } from "vuex";
import http from "../untils/request";
export default createStore({
  state: {
    access_token: '24.0617f3655ff5fb038ec07c03c13feb6a.2592000.1685800773.282335-30922380',
    zuobiao: {
      row: 0,
      line: 0,
    },
    http: http,
    number: "",
    numbers: {
      info: ""
    },
  },
  mutations: {},
  actions: {},
  modules: {},
});
