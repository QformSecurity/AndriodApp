<template>
  <div class="container">
    <div class="container-header">
      <div class="container-header-left" @click="quxiaoBack">
        <img src="../assets/back.png" />
        <p>上一步</p>
      </div>
      <img class="container-header-right" src="../assets/logo.png" />
    </div>
    <div class="title1">您要去往的楼层按钮位置是</div>
    <div class="inputs">{{zuobiao.line}}行&nbsp;{{zuobiao.row}}列</div>
    <div class="bottom">
<!--      <nut-uploader url="http://strong.xinagri.com:30080/api/strong/file/upload" @success="uploadSuccess">-->
<!--        <nut-button class="bottom-btn" @click="kaishi" type="danger">开始拍摄</nut-button>-->
<!--      </nut-uploader>-->
      <div class="bottom-btn" @click="queren">
        我已按好
      </div>
    </div>
    <nut-audio
        :url="url"
        :muted="muted"
        :autoplay="autoplay"
        :loop="false"
        type="none"
        @ended="ended"
    ></nut-audio>
  </div>
</template>

<script>
// @ is an alias to /src
import { onMounted, reactive, ref, toRefs } from "vue";
import { useRouter } from "vue-router";
import store from "@/store";
// import { Toast } from "@nutui/nutui";


export default {
  name: "Home",
  components: {
  },
  setup() {
    let router = useRouter()
    const state = reactive({
      number: store.state.number,
      zuobiao: store.state.zuobiao,
    });
    const audiodata = reactive({
      audioshow: false,
      url1: require("../assets/page04/您要去往的楼层按钮位置是第.mp3"),
      url20: "",
      url21: "",
      url2: require("../assets/page04/行.mp3"),
      url3: require("../assets/page04/列.mp3"),
      url4: require("../assets/page04/我已按好.mp3"),
      url5: require("../assets/page04/上一步.mp3"),
      audioIndex: 1,
      url: "",
      muted: false,
      autoplay: false,
    });
    let timer = ref(0);
    const queren = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.push({
            name: "Five",
          });
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("我已按好");
          audiodata.url = audiodata.url4;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const quxiao = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("上一步");
          audiodata.url = audiodata.url4;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const quxiaoBack = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("否");
          audiodata.url = audiodata.url5;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const ended = () => {
      // console.log("播放结束");
      // console.log(audiodata);
      // audiodata.audioshow = false;
      audiodata.url = "";
      audiodata.muted = false;
      audiodata.autoplay = false;
      if(audiodata.audioIndex === 1){
        setTimeout(function(){
          audiodata.audioIndex = 2;
          audiodata.url = audiodata.url20;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }, 100)
      }
      if(audiodata.audioIndex === 2){
        setTimeout(function(){
          audiodata.audioIndex = 3;
          audiodata.url = audiodata.url2;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }, 100)
      }
      if(audiodata.audioIndex === 3){
        setTimeout(function(){
          audiodata.audioIndex = 4;
          audiodata.url = audiodata.url21;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }, 100)
      }
      if(audiodata.audioIndex === 4){
        setTimeout(function(){
          audiodata.audioIndex = 5;
          audiodata.url = audiodata.url3;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }, 100)
      }
    };
    onMounted(() => {
      audiodata.url = audiodata.url1;
      audiodata.muted = true;
      audiodata.autoplay = true;
      for (let i=0;i<store.state.numberList2.length;i++){
        if(store.state.zuobiao.line === store.state.numberList2[i].num){
          audiodata.url20 = store.state.numberList2[i].url
        }
        if(store.state.zuobiao.row === store.state.numberList2[i].num){
          audiodata.url21 = store.state.numberList2[i].url
        }
      }
    });
    return {
      ...toRefs(state),
      queren,
      quxiao,
      quxiaoBack,
      ...toRefs(audiodata),
      ended,
    };
  }
};
</script>
<style scoped>
@import "../untils/common.css";
.title1 {
  width: 100%;
  text-align: center;
  font-size: 0.26rem;
  color: black;
  padding: 1rem 0 0 0;
  font-weight: 600;
}
.inputs {
  width: 70%;
  height: 3rem;
  /*border: #f1f1f1 solid 0.01rem;*/
  border-radius: 10px 10px;
  margin: 0.2rem 15%;
  background-color: #f2f2f2;
  line-height: 3rem;
  font-size: 0.5rem;
  color: #333333;
  text-align: center;
}
.title2{
  width: 100%;
  text-align: center;
  font-size: 0.5rem;
  color: #498FF2;
}
.bottom{
  width: 100%;
  position: fixed;
  z-index: 1;
  bottom: 0.5rem;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-around;
}
.bottom-btn {
  width: 80%;
  color: white;
  font-size: 0.3rem;
  padding: 0.4rem 0;
  border-radius: 0.08rem 0.08rem;
  background-color: #262626;
  text-align: center;
  font-weight: 600;
}
</style>
