<template>
  <div class="container">
    <div class="container-header">
      <div class="container-header-left" @click="quxiao">
        <img src="../assets/back.png" />
        <p>上一步</p>
      </div>
      <img class="container-header-right" src="../assets/logo.png" />
    </div>
    <div class="title1">
      您可以再次拍摄
    </div>
    <div class="title2">
      来获取当前所在楼层
    </div>
    <div class="imgBox">
      <img  src="../assets/shexiang.png" />
    </div>
<!--        <nut-input-->
<!--            v-model="base1"-->
<!--            label="图片base64"-->
<!--            type="textarea"-->
<!--            show-word-limit-->
<!--            rows="2"-->
<!--            class="tupian"-->
<!--        />-->
    <div class="bottom">
<!--      <input type="file" @change="uploadSuccess" accept="image/*" />-->
      <!--      <nut-uploader url="http://strong.xinagri.com:30080/api/strong/file/upload" @success="uploadSuccess">-->
      <!--        <nut-button class="bottom-btn" @click="kaishi" type="danger">开始拍摄</nut-button>-->
      <!--      </nut-uploader>-->
      <div class="bottom-btn" @click="kaishi">
        开始拍摄
      </div>
    </div>
    <nut-audio
        :url="url"
        :muted="muted"
        :autoplay="autoplay"
        :loop="false"
        type="none"
        @ended="ended"
    ></nut-audio>
  </div>
</template>

<script>
// @ is an alias to /src
import { onMounted, reactive, ref, toRefs } from "vue";
import { useRouter } from "vue-router";
import { Toast } from "@nutui/nutui";
import common from "@/untils/common";
import axios from "axios";
import store from "@/store";
// import http from "@/untils/request";

export default {
  name: "Home",
  components: {},
  setup() {
    let router = useRouter();
    const state = reactive({
      number: store.state.number,
      access_token: store.state.access_token,
    });
    const audiodata = reactive({
      audioshow: false,
      url1: require("../assets/page05/您可以.mp3"),
      url2: require("../assets/page05/开始拍摄.mp3"),
      url3: require("../assets/page05/上一步.mp3"),
      audioIndex: 1,
      url: "",
      muted: false,
      autoplay: false,
    });
    let timer = ref(0);
    let base1 = ref("");
    const uploadSuccess = (e) => {
      // console.log(e.target.files)
      let that = this;
      let files = e.target.files;
      let file = files[0];
      console.log(file.size / 1024)
      common.getBase64(file).then((res) => {
        common.canvasDataURL2(res, function (base64Codes) {
          // console.log(base64Codes)
          let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
          // 图片高亮处理
          // http.changePost2('https://aip.baidubce.com/oauth/2.0/token',{
          //   grant_type: 'client_credentials',
          //   client_id: 'yIs67fP0zsdm1GzvUpYUYtS8',
          //   client_secret: 'pYZxcKkdbEiRKImQEjg2CI7qH2K1aUpH',
          // }).then((res) => {
          //   console.log(res)
          // })
          // axios({
          //   method: "post", //请求方法
          //   data: {
          //     image_data: image,
          //   },
          //   headers: {
          //     "Content-Type": "application/json",
          //   },
          //   url: "http://8.142.74.18:6084/imageorgtowhite",
          // }).then((res) => {
          //   console.log(res);
          // });
          // 图片高亮处理
          //http://8.142.74.18:6084
          store.state.http
            .changePost("http://8.142.74.18:6084/imageorgtowhite", {
              image_data: image,
            })
            .then((res) => {
              console.log(res);
              console.log('返回'+res.msg);
              setTimeout(function(){
                Toast.text('返回'+res.msg)
              }, 2000)
              let retimg = res.retimg;
              axios({
                method: "post", //请求方法
                data: {
                  image: retimg,
                },
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                },
                url:
                  "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token=" +
                  state.access_token,
              }).then((res) => {
                console.log(res.data);
                let data = res.data;
                if (data) {
                  base1.value = JSON.stringify(res.data);
                  console.log(JSON.stringify(res.data));
                  let numbers = common.shibie2(data);
                  store.state.numbers = numbers;
                  console.log(numbers)
                  router.push({
                    name: "Six",
                  });
                }
              });
            });
        });
      });
      // console.log(e)
      // let base1 = e.event
      // console.log(base1)
      // canvasDataURL(base1, function (base64Codes) {
      //   let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
      //   axios({
      //     method: 'post',//请求方法
      //     data: {
      //       image: image
      //     },
      //     headers: {
      //       "Content-Type": "application/x-www-form-urlencoded",
      //     },
      //     url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token=24.ce7e9ba3e6bd6a8b057d06007dce9720.2592000.1681571075.282335-30922380',
      //   }).then(res => {
      //     console.log(res)
      //   })
      // })
    };
    const kaishi = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        // uploadSuccess()
        getphoto("camera");
        // setTimeout(function () {
        //   router.push({
        //     name: "Four",
        //   });
        // }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("开始拍摄");
          audiodata.url = audiodata.url2;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const quxiao = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("上一步");
          audiodata.url = audiodata.url3;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const getphoto = (types) => {
      var type = types;
      var options = {};
      if (type == "photo") {
        options = {
          quality: 30,
          destinationType: navigator.camera.DestinationType.DATA_URL,
          sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
          encodingType: navigator.camera.EncodingType.PNG,
          mediaType: navigator.camera.MediaType.PICTURE,
          allowEdit: true,
          correctOrientation: true, // Corrects Android orientation quirks
        };
      }
      if (type == "camera") {
        options = {
          quality: 30,
          destinationType: navigator.camera.DestinationType.DATA_URL,
          // destinationType: navigator.camera.DestinationType.FILE_URI,
          // In this app, dynamically set the picture source, Camera or photo gallery
          sourceType: navigator.camera.PictureSourceType.CAMERA,
          encodingType: navigator.camera.EncodingType.JPEG,
          mediaType: navigator.camera.MediaType.PICTURE,
          allowEdit: false,
          correctOrientation: true,
          // quality: 50,
          // destinationType: navigator.camera.DestinationType.DATA_URL,
          // sourceType: navigator.camera.PictureSourceType.CAMERA,
          // encodingType: navigator.camera.EncodingType.PNG,
          // mediaType: navigator.camera.MediaType.PICTURE,
          // allowEdit: false,
          // correctOrientation: false // Corrects Android orientation quirks
        };
      }
      let successCallback = function (imageURI) {
        let base11 = "data:image/jpeg;base64," + imageURI;
        common.canvasDataURL3(base11, function (base64Codes) {
          let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
          base1.value = image;
          axios({
            method: 'post',//请求方法
            data: {
              image: image
            },
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token='+ state.access_token,
          }).then(res => {
            console.log(res.data);
            let data = res.data;
            if (data) {
              // base1.value = JSON.stringify(res.data);
              // console.log(JSON.stringify(res.data));
              let numbers = common.shibie2(data);
              store.state.numbers = numbers;
              // console.log(numbers)
              // Toast.text('处理后'+JSON.stringify(numbers))
              // base1.value='处理后:'+JSON.stringify(numbers);
              router.push({
                name: "Six",
              });
            }
          })
        })
        // common.canvasDataURL2(imageURI, function (base64Codes) {
        //   let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
        //   // base1.value='高亮前:'+image;
        //   // Toast.text('高亮前:'+image)
        //   // 图片高亮处理
        //   axios({
        //     method: "post", //请求方法
        //     data: {
        //       image_data: image,
        //     },
        //     headers: {
        //       "Content-Type": "application/json",
        //     },
        //     url: "http://8.142.74.18:6084/imageorgtowhite",
        //   }).then((res) => {
        //     // console.log(res.data);
        //     let resData = res.data
        //     // Toast.text('返回'+JSON.stringify(resData))
        //     let retimg = resData.retimg;
        //     // Toast.text('高亮后:'+retimg)
        //     // base1.value='高亮前:'+retimg;
        //     axios({
        //       method: "post", //请求方法
        //       data: {
        //         image: retimg,
        //       },
        //       headers: {
        //         "Content-Type": "application/x-www-form-urlencoded",
        //       },
        //       url:
        //           "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token=" +
        //           state.access_token,
        //     }).then((res) => {
        //       console.log(res.data);
        //       let data = res.data;
        //       if (data) {
        //         // base1.value = JSON.stringify(res.data);
        //         // console.log(JSON.stringify(res.data));
        //         let numbers = common.shibie2(data);
        //         store.state.numbers = numbers;
        //         // console.log(numbers)
        //         // Toast.text('处理后'+JSON.stringify(numbers))
        //         // base1.value='处理后:'+JSON.stringify(numbers);
        //         router.push({
        //           name: "Six",
        //         });
        //       }
        //     });
        //   });
        //   //http://8.142.74.18:6084
        //   // store.state.http
        //   //     .changePost("http://8.142.74.18:6084/imageorgtowhite", {
        //   //       image_data: image,
        //   //     })
        //   //     .then((res) => {
        //   //       console.log(res);
        //   //       setTimeout(function(){
        //   //         Toast.text('返回'+res.msg)
        //   //       }, 2000)
        //   //       let retimg = res.retimg;
        //   //       axios({
        //   //         method: "post", //请求方法
        //   //         data: {
        //   //           image: retimg,
        //   //         },
        //   //         headers: {
        //   //           "Content-Type": "application/x-www-form-urlencoded",
        //   //         },
        //   //         url:
        //   //             "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token=" +
        //   //             state.access_token,
        //   //       }).then((res) => {
        //   //         console.log(res.data);
        //   //         let data = res.data;
        //   //         if (data) {
        //   //           base1.value = JSON.stringify(res.data);
        //   //           console.log(JSON.stringify(res.data));
        //   //           let numbers = common.shibie2(data);
        //   //           store.state.numbers = numbers;
        //   //           console.log(numbers)
        //   //           router.push({
        //   //             name: "Six",
        //   //           });
        //   //         }
        //   //       });
        //   //     });
        // });
        // base1.value = imageURI;
        // base1.value="data:image/jpeg;base64,"+imageURI;
        // if(base1.value.length/1024>1025) {//大于1M，进行压缩上传
        //   canvasDataURL(base1, function (base64Codes) {
        //     base1.value=base64Codes;
        //   })
        // }
        // Toast.text(base1.value)
      };
      let errorCallback = function () {};
      navigator.camera.getPicture(successCallback, errorCallback, options);
    };
    const ended = () => {
      // console.log("播放结束");
      // audiodata.audioshow = false;
      audiodata.url = "";
      audiodata.muted = false;
      audiodata.autoplay = false;
    };
    onMounted(() => {
      audiodata.url = audiodata.url1;
      audiodata.muted = true;
      audiodata.autoplay = true;
    });
    return {
      ...toRefs(state),
      kaishi,
      uploadSuccess,
      quxiao,
      getphoto,
      base1,
      ...toRefs(audiodata),
      ended,
    };
  },
};
</script>
<style scoped>
@import "../untils/common.css";
.title1 {
  width: 100%;
  text-align: center;
  font-size: 0.26rem;
  color: black;
  padding: 1rem 0 0 0;
  font-weight: 600;
}
.imgBox{
  width: 100%;
  margin: 0.5rem 0 0 0;
  text-align: center;
}
.imgBox img{
  width: 50%;
}
.title2 {
  width: 100%;
  text-align: center;
  font-size: 0.26rem;
  color: #afabab;
  font-weight: 600;
  padding: 0.04rem 0 0 0;
}
.bottom {
  width: 100%;
  position: fixed;
  z-index: 1;
  bottom: 0.5rem;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-around;
}
.bottom-btn {
  width: 80%;
  color: white;
  font-size: 0.3rem;
  padding: 0.4rem 0;
  border-radius: 0.08rem 0.08rem;
  background-color: #262626;
  text-align: center;
  font-weight: 600;
}
</style>
