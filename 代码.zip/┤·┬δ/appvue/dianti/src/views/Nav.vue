<template>
  <div class="container">
    <div class="title1"><p>用户隐私政策</p></div>
    <div class="yinsi">
      1.隐私政策
      隐私政策

      LiftMeUp尊重并保护所有使用服务用户的个人隐私权。除本隐私权政策另有规定外，在未征得您事先许可的情况下，LiftMeUp不会将这些信息对外披露或向第三方提供。LiftMeUp会不时更新本隐私权政策。您在同意LiftMeUp服务使用协议之时，即视为您已经同意本隐私权政策全部内容。本隐私权政策属于LiftMeUp服务使用协议不可分割的一部分。

      1. 适用范围

      (a) 在您使用LiftMeUp网络服务，或访问LiftMeUp平台网页时，LiftMeUp自动接收并记录的您的浏览器和计算机上的信息，包括但不限于您的IP地址、浏览器的类型、使用的语言、访问日期和时间、软硬件特征信息及您需求的网页记录等数据；

      您了解并同意，以下信息不适用本隐私权政策：

      (a) LiftMeUp收集到的您在LiftMeUp发布的有关信息数据；

      (b) 违反法律规定或违反LiftMeUp规则行为及LiftMeUp已对您采取的措施。

      2. 信息使用

      (a)LiftMeUp不会向任何无关第三方提供、出售、出租、分享或交易您的个人信息，除非事先得到您的许可，或该第三方和LiftMeUp（含LiftMeUp关联公司）单独或共同为您提供服务，且在该服务结束后，其将被禁止访问包括其以前能够访问的所有这些资料。

      (b) LiftMeUp亦不允许任何第三方以任何手段收集、编辑、出售或者无偿传播您的个人信息。任何LiftMeUp平台用户如从事上述活动，一经发现，LiftMeUp有权立即终止与该用户的服务协议。

      3. 信息披露

      在如下情况下，LiftMeUp将依据您的个人意愿或法律的规定全部或部分的披露您的个人信息：

      (a) 经您事先同意，向第三方披露；

      (b)为提供您所要求的产品和服务，而必须和第三方分享您的个人信息；

      (c) 根据法律的有关规定，或者行政或司法机构的要求，向第三方或者行政、司法机构披露；

      (d) 如您出现违反中国有关法律、法规或者LiftMeUp服务协议或相关规则的情况，需要向第三方披露；

      (e) 如您是适格的知识产权投诉人并已提起投诉，应被投诉人要求，向被投诉人披露，以便双方处理可能的权利纠纷；

      (f) 在LiftMeUp平台上创建的某一交易中，如交易任何一方履行或部分履行了交易义务并提出信息披露请求的，LiftMeUp有权决定向该用户提供其交易对方的联络方式等必要信息，以促成交易的完成或纠纷的解决。

      (g) 其它LiftMeUp根据法律、法规或者网站政策认为合适的披露。

      4. 信息存储和交换

      LiftMeUp收集的有关您的信息和资料将保存在LiftMeUp及（或）其关联公司的服务器上，这些信息和资料可能传送至您所在国家、地区或LiftMeUp收集信息和资料所在地的境外并在境外被访问、存储和展示。

      5. 采集图片的使用

      (a) 在您未拒绝接受“采集图片”的情况下，LiftMeUp会在您的手机上设定或取用拍摄的图片。

      (b) 您有权选择接受或拒绝接受“采集图片”。您可以通过修改程序设置的方式拒绝“采集图片”。但如果您选择拒绝“采集图片”，则您可能无法登录或使用依赖于“采集图片”为核心的LiftMeUp服务或功能。

      (c) 通过LiftMeUp所采集的图片，所取得的有关信息，将适用本政策。

      6. 信息安全

      (a) LiftMeUp帐号均有安全保护功能，请妥善保管您的用户名及密码信息。LiftMeUp将通过对用户密码进行加密等安全措施确保您的信息不丢失，不被滥用和变造。尽管有前述安全措施，但同时也请您注意在信息网络上不存在“完善的安全措施”。

      (b) 在使用LiftMeUp网络服务进行网上交易时，您不可避免的要向交易对方或潜在的交易对

      7.本隐私政策的更改

      (a)如果决定更改隐私政策，我们会在本政策中、本公司网站中以及我们认为适当的位置发布这些更改，以便您了解我们如何收集、使用您的个人信息，哪些人可以访问这些信息，以及在什么情况下我们会透露这些信息。

      (b)本公司保留随时修改本政策的权利，因此请经常查看。如对本政策作出重大更改，本公司会通过网站通知的形式告知。

      请您妥善保护自己的个人信息，仅在必要的情形下向他人提供。

      2.服务条款
      软件服务及隐私条款
      欢迎您使用软件及服务，以下内容请仔细阅读。
      1、保护用户个人信息是一项基本原则，我们将会采取合理的措施保护用户的个人信息。除法律法规规定的情形外，未经用户许可我们不会向第三方公开、透漏个人信息。APP对相关信息采用专业加密存储与传输方式，保障用户个人信息安全，如果您选择同意使用APP软件， 即表示您认可并接受APP服务条款及其可能随时更新的内容。

      2、我们将会使用您的以下功能：麦克风、喇叭、WIFI网络、蜂窝通信网络，如果您禁止APP使用以上相关服务和功能，您将自行承担不能获得或享用APP相应服务的后果。

      3、为了能够让APP定位服务更精确，可能会收集并处理有关您实际所在位置信息（例如移动设备发送的GPS信号），WI-FI接入点和 基站位置信息。我们将对上述信息实施技术保护措施，以最大程度保护这些信息不被第三方非法获得，同时，您可以自行选择拒绝我们基于技术必要性 收集的这些信息，并自行承担不能获得或享用APP相应服务的后果。

      4、由于您的自身行为或不可抗力等情形，导致上述可能涉及您隐私或您认为是私人信息的内容发生被泄露、批漏，或被第三方获取、使用、转让等情形的，均由您自行承担不利后果，我们对此不承担任何责任。

      5、我们拥有对上述条款的最终解释权。
    </div>
<!--    <div class="bottom">-->
<!--      <div class="bottom-btn" @click="queren">同意并开始</div>-->
<!--    </div>-->
    <!--    <nut-audio-->
    <!--      :url="url"-->
    <!--      :muted="muted"-->
    <!--      :autoplay="autoplay"-->
    <!--      :loop="false"-->
    <!--      type="none"-->
    <!--      @ended="ended"-->
    <!--    ></nut-audio>-->
  </div>
</template>

<script>
// @ is an alias to /src
import { reactive, toRefs } from "vue";
import { useRouter } from "vue-router";
// import { Toast } from "@nutui/nutui";
// import store from "@/store";
export default {
  name: "Home",
  components: {},
  setup() {
    let router = useRouter();
    const state = reactive({
      number: "",
    });
    const audiodata = reactive({
      // audioshow: false,
      // url1: require("../assets/page01/请输入您想要去往的楼层.mp3"),
      // url2: require("../assets//page01/确认.mp3"),
      // url3: require("../assets//page01/请输入.mp3"),
      // url: "",
      // muted: false,
      // autoplay: false,
    });
    // let timer = ref(0);
    const queren = () => {
      router.push({
        name: "Home",
      });
      // timer.value++;
      // if (timer.value === 2) {
      //   timer.value = 0;
      //   console.log("双击"); //双击要执行的事件处理
      //   if (state.number === "") {
      //     // Toast.warn("请输入要去的楼层");
      //     audiodata.url = audiodata.url1;
      //     audiodata.muted = true;
      //     audiodata.autoplay = true;
      //     return false;
      //   }
      //   store.state.number = state.number;
      //   setTimeout(function () {
      //     router.push({
      //       name: "About",
      //     });
      //   }, 500);
      // }
      // setTimeout(function () {
      //   if (timer.value === 1) {
      //     timer.value = 0;
      //     console.log("单击"); //双击要执行的事件处理
      //     // audiodata.audioshow = true;
      //     if (state.number === "") {
      //       audiodata.url = audiodata.url1;
      //       audiodata.muted = true;
      //       audiodata.autoplay = true;
      //     } else {
      //       audiodata.url = audiodata.url2;
      //       audiodata.muted = true;
      //       audiodata.autoplay = true;
      //     }
      //     // Toast.text("请输入要去的楼层");
      //   }
      // }, 250);
    };
    const ended = () => {
      // console.log("播放结束");
      // audiodata.audioshow = false;
      // audiodata.url = "";
      // audiodata.muted = false;
      // audiodata.autoplay = false;
    };
    // const shuru = () => {
    //   // console.log('输入框')
    //   audiodata.url = audiodata.url3;
    //   audiodata.muted = true;
    //   audiodata.autoplay = true;
    // };
    // onMounted(() => {
    //   setTimeout(function(){
    //     audiodata.url = audiodata.url1;
    //     audiodata.muted = true;
    //     audiodata.autoplay = true;
    //   },1000)
    //   let numberList = [];
    //   let numberListK = {};
    //   for (let i = 0; i < 32; i++) {
    //     numberListK = {};
    //     if (i < 31) {
    //       numberListK = {
    //         num: i,
    //         url: require("../assets/shuzi/" + i + "层.mp3"),
    //       };
    //     }
    //     if (i === 31) {
    //       numberListK.num = "未知";
    //       numberListK.url = require("../assets/shuzi/未知.mp3");
    //     }
    //     // if (i === 12) {
    //     //   numberListK.num = 30;
    //     //   numberListK.url = require("../assets/shuzi/30.mp3");
    //     // }
    //     // if (i === 13) {
    //     //   numberListK.num = "未知";
    //     //   numberListK.url = require("../assets/shuzi/未知.mp3");
    //     // }
    //     numberList.push(numberListK);
    //   }
    //   store.state.numberList = numberList;
    //   let numberList2 = [];
    //   let numberListK2 = {};
    //   for (let i = 0; i < 11; i++) {
    //     numberListK = {};
    //     if (i < 10) {
    //       numberListK2 = {
    //         num: i,
    //         url: require("../assets/shuzi/" + i + ".mp3"),
    //       };
    //     }
    //     if (i === 10) {
    //       numberListK2.num = "未知";
    //       numberListK2.url = require("../assets/shuzi/未知.mp3");
    //     }
    //     // if (i === 12) {
    //     //   numberListK.num = 30;
    //     //   numberListK.url = require("../assets/shuzi/30.mp3");
    //     // }
    //     // if (i === 13) {
    //     //   numberListK.num = "未知";
    //     //   numberListK.url = require("../assets/shuzi/未知.mp3");
    //     // }
    //     numberList2.push(numberListK2);
    //   }
    //   store.state.numberList2 = numberList2;
    //   // console.log(store.state.numberList)
    // });
    return {
      state,
      queren,
      ...toRefs(audiodata),
      ended,
      // shuru,
    };
  },
};
</script>
<style scoped>
@import "../untils/common.css";
.title1 {
  width: 100%;
  text-align: center;
  margin: 0 0 0 0;
  font-weight: 600;
}
.title1 p {
  display: inline-block;
  font-size: 0.26rem;
  color: black;
  border-bottom: black 0.02rem solid;
  padding: 0 0 0.05rem 0;
}
.inputs {
  width: 80%;
  height: 3.5rem;
  /*border: #f1f1f1 solid 0.01rem;*/
  border-radius: 10px 10px;
  margin: 0.2rem 10%;
  background-color: #f2f2f2;
}
.inputs input {
  width: 100%;
  height: 3.5rem;
  line-height: 3.5rem;
  background: transparent;
  font-size: 1.6rem;
  color: #333333;
  border: 0;
  outline: none;
  text-align: center;
}
.inputs input::placeholder {
  color: #333333;
  font-size: 0.6rem;
}
.bottom {
  width: 100%;
  /*position: fixed;*/
  /*z-index: 1;*/
  /*bottom: 0.5rem;*/
  padding: 0.1rem 0 0 0;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-around;
}
.bottom-btn {
  width: 70%;
  color: white;
  font-size: 0.2rem;
  padding: 0.2rem 0;
  border-radius: 0.08rem 0.08rem;
  background-color: #262626;
  text-align: center;
}
.yinsi {
  width: 80%;
  margin: 0.1rem 10%;
  height: 4rem;
  overflow-y: scroll;
  border: #262626 2px solid;
  border-radius: 0.02rem 0.02rem;
  padding: 0.1rem 0;
  font-size: 0.14rem;
  color: #262626;
}
</style>
