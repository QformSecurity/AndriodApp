<template>
  <div class="container">
    <div class="container-header">
      <div class="container-header-left" @click="quxiaoBack">
        <img src="../assets/back.png" />
        <p>上一步</p>
      </div>
      <img class="container-header-right" src="../assets/logo.png" />
    </div>
    <div class="title1">请确认您的目的地是否为</div>
    <div class="inputs">
      {{ number }}
    </div>
    <div class="bottom">
      <div class="bottom-btn1"  @click="queren">
        是
      </div>
      <div class="bottom-btn2"  @click="quxiao">
        否
      </div>
    </div>
    <nut-audio
        :url="url"
        :muted="muted"
        :autoplay="autoplay"
        :loop="false"
        type="none"
        @ended="ended"
    ></nut-audio>
  </div>
</template>

<script>
// @ is an alias to /src
import { reactive, ref, toRefs, onMounted } from "vue";
import { useRouter } from "vue-router";
import { Toast } from "@nutui/nutui";
import store from "@/store";

export default {
  name: "Home",
  components: {},
  setup() {
    let router = useRouter();
    const state = reactive({
      number: store.state.number,
      weizhi: true,
    });
    const audiodata = reactive({
      audioshow: false,
      url1: require("../assets/page02/请确认您的目的地是否为.mp3"),
      url2: require("../assets/shuzi/未知.mp3"),
      url3: require("../assets/page02/是.mp3"),
      url4: require("../assets/page02/否.mp3"),
      url5: require("../assets/page02/上一步.mp3"),
      audioIndex: 1,
      url: "",
      muted: false,
      autoplay: false,
    });
    let timer = ref(0);
    const queren = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.push({
            name: "Three",
          });
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          audiodata.url = audiodata.url3;
          audiodata.muted = true;
          audiodata.autoplay = true;
          // Toast.text("是");
        }
      }, 250);
    };
    const quxiao = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("否");
          audiodata.url = audiodata.url4;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const quxiaoBack = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("否");
          audiodata.url = audiodata.url5;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const ended = () => {
      // console.log("播放结束");
      // audiodata.audioshow = false;
      audiodata.url = "";
      audiodata.muted = false;
      audiodata.autoplay = false;
      if(audiodata.audioIndex === 1){
        setTimeout(function(){
          audiodata.audioIndex = 2;
          audiodata.url = audiodata.url2;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }, 100)
      }
      if(audiodata.audioIndex === 2){
        if(state.weizhi === true){
          setTimeout(function () {
            router.back();
          }, 500);
        }
      }
    };
    onMounted(() => {
      audiodata.url = audiodata.url1;
      audiodata.muted = true;
      audiodata.autoplay = true;
      for (let i=0;i<store.state.numberList.length;i++){
        if(store.state.number === store.state.numberList[i].num){
          audiodata.url2 = store.state.numberList[i].url;
          state.weizhi = false;
        }
      }
    });
    return {
      ...toRefs(state),
      queren,
      quxiao,
      quxiaoBack,
      ...toRefs(audiodata),
      ended,
    };
  },
};
</script>
<style scoped>
@import "../untils/common.css";
.title1 {
  width: 100%;
  text-align: center;
  font-size: 0.26rem;
  color: black;
  font-weight: 600;
  padding: 1rem 0 0 0;
}
.inputs {
  width: 60%;
  height: 3rem;
  /*border: #f1f1f1 solid 0.01rem;*/
  border-radius: 10px 10px;
  margin: 0.2rem 20%;
  background-color: #f2f2f2;
  line-height: 3rem;
  font-size: 1.6rem;
  color: #333333;
  text-align: center;
}
.bottom {
  width: 100%;
  position: fixed;
  z-index: 1;
  bottom: 0.5rem;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-around;
}
.bottom-btn1 {
  width: 40%;
  color: white;
  font-size: 0.2rem;
  padding: 0.2rem 0;
  border-radius: 0.08rem 0.08rem;
  background-color: #262626;
  text-align: center;
}
.bottom-btn2 {
  width: 40%;
  color: white;
  font-size: 0.2rem;
  padding: 0.2rem 0;
  border-radius: 0.08rem 0.08rem;
  background-color: #bfbfbf;
  text-align: center;
}
</style>
