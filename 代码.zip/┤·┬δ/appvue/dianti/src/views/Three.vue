<template>
  <div class="container">
    <div class="container-header">
      <div class="container-header-left" @click="quxiaoBack">
        <img src="../assets/back.png" />
        <p>上一步</p>
      </div>
      <img class="container-header-right" src="../assets/logo.png" />
    </div>
    <div class="title1">请拍摄电梯区域按钮</div>
    <div class="imgBox">
      <img  src="../assets/shexiang.png" />
    </div>
<!--    <nut-input-->
<!--        v-model="base1"-->
<!--        label="图片base64"-->
<!--        type="textarea"-->
<!--        show-word-limit-->
<!--        rows="2"-->
<!--        class="tupian"-->
<!--    />-->
<!--    <img id="imgTwo" src="" />-->
    <div class="bottom">
<!--      <input  type="file" @change="uploadSuccess" accept="image/*" />-->
      <div class="bottom-btn" @click="kaishi">
        开始拍摄
      </div>
<!--      <nut-uploader url="http://strong.xinagri.com:30080/api/strong/file/upload" @change="uploadSuccess">-->
<!--        <nut-button class="bottom-btn" @click="kaishi" type="danger">开始拍摄</nut-button>-->
<!--      </nut-uploader>-->
<!--      <nut-button class="bottom-btn" @click="kaishi" type="danger">开始拍摄</nut-button>-->
    </div>
    <nut-audio
        :url="url"
        :muted="muted"
        :autoplay="autoplay"
        :loop="false"
        type="none"
        @ended="ended"
    ></nut-audio>
  </div>
</template>

<script>
// @ is an alias to /src
import { reactive, ref, toRefs, onBeforeMount, onMounted } from "vue";
import { useRouter } from "vue-router";
// import { Toast } from "@nutui/nutui";
import common from "@/untils/common";
import axios from "axios";
import store from "@/store";
import http from "@/untils/request";

export default {
  name: "Home",
  components: {
  },
  setup() {
    let router = useRouter()
    const state = reactive({
      number: store.state.number,
      access_token: store.state.access_token,
    });
    const audiodata = reactive({
      audioshow: false,
      url1: require("../assets/page03/请拍摄电梯区域按钮.mp3"),
      url2: require("../assets/page03/开始拍摄.mp3"),
      url3: require("../assets/page03/是.mp3"),
      url4: require("../assets/page03/否.mp3"),
      url5: require("../assets/page03/上一步.mp3"),
      audioIndex: 1,
      url: "",
      muted: false,
      autoplay: false,
    });
    let timer = ref(0);
    // const paishe = ()=>{
    //   // router.push({
    //   //   name: "About",
    //   // });
    // }
    const uploadSuccess=(e)=>{
      // console.log(e.target.files)
      // let that = this
      let files = e.target.files
      let file = files[0]
      common.getBase64(file).then(res => {
        common.canvasDataURL2(res, function (base64Codes) {
          // console.log(base64Codes)
          let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
          axios({
            method: 'post',//请求方法
            data: {
              image: image
            },
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token='+ state.access_token,
          }).then(res => {
            console.log(res.data)
            let data = res.data
            if(data){
              base1.value = JSON.stringify(res.data)
              console.log(JSON.stringify(res.data))
              let zuobiao = common.shibie(state.number,data)
              store.state.zuobiao = zuobiao
              router.push({
                name: "Four",
              });
            }
          })
        })
      })
      // console.log(e)
      // let base1 = e.event
      // console.log(base1)
      // canvasDataURL(base1, function (base64Codes) {
      //   let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
      //   axios({
      //     method: 'post',//请求方法
      //     data: {
      //       image: image
      //     },
      //     headers: {
      //       "Content-Type": "application/x-www-form-urlencoded",
      //     },
      //     url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token=24.ce7e9ba3e6bd6a8b057d06007dce9720.2592000.1681571075.282335-30922380',
      //   }).then(res => {
      //     console.log(res)
      //   })
      // })
    }
    let base1 = ref("");
    const kaishi = ()=>{
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        // uploadSuccess()
        getphoto("camera");
        // setTimeout(function () {
        //   router.push({
        //     name: "Four",
        //   });
        // }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("开始拍摄");
          audiodata.url = audiodata.url2;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    }
    const quxiao = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("上一步");
          audiodata.url = audiodata.url4;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const quxiaoBack = () => {
      timer.value++;
      if (timer.value === 2) {
        timer.value = 0;
        setTimeout(function () {
          router.back();
        }, 500);
      }
      setTimeout(function () {
        if (timer.value === 1) {
          timer.value = 0;
          // Toast.text("否");
          audiodata.url = audiodata.url5;
          audiodata.muted = true;
          audiodata.autoplay = true;
        }
      }, 250);
    };
    const getphoto = (types)=>{
      var type=types;
      var options ={};
      if(type=="photo"){
        options = {
          quality: 30,
          destinationType: navigator.camera.DestinationType.DATA_URL,
          sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
          encodingType: navigator.camera.EncodingType.PNG,
          mediaType: navigator.camera.MediaType.PICTURE,
          allowEdit: true,
          correctOrientation: true // Corrects Android orientation quirks
        };
      }
      if(type=="camera"){
        options = {
          quality: 30,
          destinationType: navigator.camera.DestinationType.DATA_URL,
          // destinationType: navigator.camera.DestinationType.FILE_URI,
          // In this app, dynamically set the picture source, Camera or photo gallery
          sourceType:  navigator.camera.PictureSourceType.CAMERA,
          encodingType: navigator.camera.EncodingType.JPEG,
          mediaType: navigator.camera.MediaType.PICTURE,
          allowEdit: false,
          correctOrientation: true
          // quality: 50,
          // destinationType: navigator.camera.DestinationType.DATA_URL,
          // sourceType: navigator.camera.PictureSourceType.CAMERA,
          // encodingType: navigator.camera.EncodingType.PNG,
          // mediaType: navigator.camera.MediaType.PICTURE,
          // allowEdit: false,
          // correctOrientation: false // Corrects Android orientation quirks
        };
      }
      let successCallback = function(imageURI) {
        // base1.value = imageURI;
        let base11 = "data:image/jpeg;base64," + imageURI;
        common.canvasDataURL3(base11, function (base64Codes) {
          let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
          base1.value = image;
          axios({
            method: 'post',//请求方法
            data: {
              image: image
            },
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token='+ state.access_token,
          }).then(res => {
            console.log(res.data)
            let data = res.data
            if(data){
              // base1.value = JSON.stringify(res.data)
              // console.log(JSON.stringify(res.data))
              let zuobiao = common.shibie(state.number,data)
              store.state.zuobiao = zuobiao
              router.push({
                name: "Four",
              });
            }
          })
        })


        // common.canvasDataURL2(imageURI, function (base64Codes) {
        //   base1.value=base64Codes;
        //   let image = base64Codes.replace(/^data:image\/\w+;base64,/, "");
        //   axios({
        //     method: 'post',//请求方法
        //     data: {
        //       image: image
        //     },
        //     headers: {
        //       "Content-Type": "application/x-www-form-urlencoded",
        //     },
        //     url: 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate?access_token='+ state.access_token,
        //   }).then(res => {
        //     console.log(res.data)
        //     let data = res.data
        //     if(data){
        //       base1.value = JSON.stringify(res.data)
        //       console.log(JSON.stringify(res.data))
        //       let zuobiao = common.shibie(state.number,data)
        //       store.state.zuobiao = zuobiao
        //       router.push({
        //         name: "Four",
        //       });
        //     }
        //   })
        // })
        // base1.value = imageURI;
        // base1.value="data:image/jpeg;base64,"+imageURI;
        // if(base1.value.length/1024>1025) {//大于1M，进行压缩上传
        //   canvasDataURL(base1, function (base64Codes) {
        //     base1.value=base64Codes;
        //   })
        // }
        // Toast.text(base1.value)
      };
      let errorCallback = function() {};
      navigator.camera.getPicture(successCallback, errorCallback, options);
    }
    onBeforeMount(() => {
      // access_token
      // https://aip.baidubce.com
      http.changePost2('https://aip.baidubce.com/oauth/2.0/token',{
        grant_type: 'client_credentials',
        client_id: 'yIs67fP0zsdm1GzvUpYUYtS8',
        client_secret: 'pYZxcKkdbEiRKImQEjg2CI7qH2K1aUpH',
      }).then((res) => {
        // console.log(res)
        // Toast.text(res.access_token)
        state.access_token = res.access_token
          store.state.access_token = res.access_token;
        // base1.value =  state.access_token
      })
      // axios({
      //   method: 'post',//请求方法
      //   data: {
      //     grant_type: 'client_credentials',
      //     client_id: 'yIs67fP0zsdm1GzvUpYUYtS8',
      //     client_secret: 'pYZxcKkdbEiRKImQEjg2CI7qH2K1aUpH',
      //   },
      //   headers: {
      //     "Content-Type": "application/x-www-form-urlencoded",
      //   },
      //   url: 'https://aip.baidubce.com/oauth/2.0/token',
      // }).then(res => {
      //   console.log(res)
      //   // state.access_token = res.access_token
      //   // store.state.access_token = res.access_token;
      // })
    })
    const ended = () => {
      // console.log("播放结束");
      // audiodata.audioshow = false;
      audiodata.url = "";
      audiodata.muted = false;
      audiodata.autoplay = false;
    };
    onMounted(() => {
      audiodata.url = audiodata.url1;
      audiodata.muted = true;
      audiodata.autoplay = true;
    });
    return {
      ...toRefs(state),
      kaishi,
      getphoto,
      uploadSuccess,
      quxiao,
      quxiaoBack,
      base1,
      ...toRefs(audiodata),
      ended,
    };
  }
};
</script>
<style scoped>
@import "../untils/common.css";
.title1 {
  width: 100%;
  text-align: center;
  font-size: 0.26rem;
  color: black;
  font-weight: 600;
  padding: 1rem 0 0 0;
}
.imgBox{
  width: 100%;
  margin: 0.5rem 0 0 0;
  text-align: center;
}
.imgBox img{
  width: 50%;
}
.title2{
  width: 100%;
  text-align: center;
  font-size: 2rem;
  color: #498FF2;
}
.tupian{
  width: 94%;
  margin: 0.1rem 3%;
  border: 1px solid #f1f1f1;
  border-radius: 4px 4px;
}
.bottom{
  width: 100%;
  position: fixed;
  z-index: 1;
  bottom: 1rem;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-around;
}
.bottom-btn {
  width: 80%;
  color: white;
  font-size: 0.3rem;
  padding: 0.4rem 0;
  border-radius: 0.08rem 0.08rem;
  background-color: #262626;
  text-align: center;
  font-weight: 600;
}
</style>
